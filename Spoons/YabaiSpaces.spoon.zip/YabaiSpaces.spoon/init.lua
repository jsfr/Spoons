local obj = {}
obj.__index = obj
obj.name = "YabaiSpaces"
obj.version = "1.1"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.menuItem = nil
obj.yabaiPath = "/opt/homebrew/bin/yabai"
obj.jqPath = "/opt/homebrew/bin/jq"
obj.task = nil
obj.logger = nil
local function space_text(space, active_space)
  local space_font = {name = "CD Numbers", size = 12}
  local inactive_color = {red = 0.34, green = 0.37, blue = 0.39, alpha = 1.0}
  local active_style = {font = space_font, baselineOffset = -5.0}
  local inactive_style = {font = space_font, baselineOffset = -5.0, color = inactive_color}
  local space_icons = {f = "a", "e", "f", "g", "i", "j", "k", "l", "m", "n", "o"}
  local space_icon_unknown = "h"
  local function _1_()
    local t_2_ = space_icons
    if (nil ~= t_2_) then
      t_2_ = (t_2_)[space]
    else
    end
    return t_2_
  end
  local function _4_()
    if (space == active_space) then
      return active_style
    else
      return inactive_style
    end
  end
  return hs.styledtext.new((_1_() or space_icon_unknown), _4_())
end
local function callback(exit_code, std_out, _)
  if (exit_code == 0) then
    local result = hs.json.decode(std_out)
    if (result ~= nil) then
      local visible_spaces = result.spaces
      local active_space = result.focused
      local title = hs.styledtext.new(" ")
      for _0, space in pairs(visible_spaces) do
        title = (title .. space_text(space, active_space))
      end
      return (obj.menuItem):setTitle(title)
    else
      return nil
    end
  else
    return nil
  end
end
local function terminate_task()
  if ((obj.task ~= nil) and (obj.task):isRunning()) then
    do end (obj.task):terminate()
    obj.task = nil
    return nil
  else
    return nil
  end
end
local function set_environment(task)
  local environment = task:environment()
  environment.JQ_PATH = obj.jqPath
  environment.YABAI_PATH = obj.yabaiPath
  return task:setEnvironment(environment)
end
local function run_task()
  obj.task = set_environment(hs.task.new(hs.spoons.resourcePath("spaces.sh"), callback)):start()
  return nil
end
obj.add_signals = function(self)
  return set_environment(hs.task.new(hs.spoons.resourcePath("signals.sh"), nil)):start()
end
obj.update = function(self)
  terminate_task()
  return run_task()
end
obj.init = function(self)
  self.logger = hs.logger.new("YabaiSpaces")
  self.menuItem = hs.menubar.new()
  self:add_signals()
  hs.styledtext.loadFont(hs.spoons.resourcePath("cdnumbers.ttf"))
  do end (self.menuItem):setTitle("[Updating...]")
  return self:update()
end
return obj
