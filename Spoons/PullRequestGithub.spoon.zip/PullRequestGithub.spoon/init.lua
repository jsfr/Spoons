local obj = {}
obj.__index = obj
obj.name = "PullRequestGithub"
obj.version = "2.0"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.username = nil
obj.skateItem = nil
obj.skatePath = "/opt/homebrew/bin/skate"
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local function fetch_token(skatePath, skateItem)
  local command = (skatePath .. " get " .. skateItem)
  local handle = io.popen(command)
  local function close_handlers_13_(ok_14_, ...)
    handle:close()
    if ok_14_ then
      return ...
    else
      return error(..., 0)
    end
  end
  local function _2_()
    local output = handle:read("*a")
    return output:gsub("^%s*(.-)%s*$", "%1")
  end
  local _4_
  do
    local t_3_ = _G
    if (nil ~= t_3_) then
      t_3_ = t_3_.package
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.loaded
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.fennel
    else
    end
    _4_ = t_3_
  end
  local or_8_ = _4_ or _G.debug
  if not or_8_ then
    local function _9_()
      return ""
    end
    or_8_ = {traceback = _9_}
  end
  return close_handlers_13_(_G.xpcall(_2_, or_8_.traceback))
end
local state = {["user-prs"] = {}, ["review-prs"] = {}, ["involved-prs"] = {}, token = nil, ["last-update"] = nil}
local function make_icon()
  local ascii = "ASCII:\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . . . . . . . . . . . . . .\n. . 1 . . . 1 . . . 8 . . . 8 . .\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . 2 . . . . . . . 7 . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 4 . . 5 . . . 6 . . . . .\n. . . . 2 . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . 3 . . . 3 . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . ."
  local context = {{strokeColor = {red = 1, green = 1, blue = 1, alpha = 1}, fillColor = {alpha = 0}, lineWidth = 1.2, shouldClose = false}}
  return hs.image.imageFromASCII(ascii, context)
end
local function get_status_emoji(pull_request)
  local _11_
  do
    local t_10_ = pull_request
    if (nil ~= t_10_) then
      t_10_ = t_10_.mergeable
    else
    end
    _11_ = t_10_
  end
  if (_11_ == "CONFLICTING") then
    return "\226\154\148\239\184\143 "
  else
    local case_13_
    do
      local t_14_ = pull_request
      if (nil ~= t_14_) then
        t_14_ = t_14_["review-decision"]
      else
      end
      case_13_ = t_14_
    end
    if (case_13_ == "APPROVED") then
      return "\226\156\133 "
    elseif (case_13_ == "CHANGES_REQUESTED") then
      return "\226\157\140 "
    else
      local _ = case_13_
      return "\226\143\179 "
    end
  end
end
local function get_ci_status_style(pull_request)
  local case_18_
  do
    local t_19_ = pull_request
    if (nil ~= t_19_) then
      t_19_ = t_19_["ci-status"]
    else
    end
    case_18_ = t_19_
  end
  if (case_18_ == "SUCCESS") then
    return {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
  elseif (case_18_ == "FAILURE") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  elseif (case_18_ == "ERROR") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  else
    local _ = case_18_
    return {}
  end
end
local function get_menu_title(total_count)
  return hs.styledtext.new(tostring(total_count))
end
local function get_error_title()
  local error_style = {color = {red = 1.0, green = 0, blue = 0, alpha = 1.0}}
  return hs.styledtext.new("error", error_style)
end
local function show_error(error_message)
  obj.logger.e(error_message)
  obj.menuItem:setTitle(get_error_title())
  return obj.menuItem:setMenu(nil)
end
local function get_title(pull_request)
  local title
  do
    local t_22_ = pull_request
    if (nil ~= t_22_) then
      t_22_ = t_22_.title
    else
    end
    title = t_22_
  end
  local emoji = get_status_emoji(pull_request)
  local draft_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
  local ci_style = get_ci_status_style(pull_request)
  local text
  local _25_
  do
    local t_24_ = pull_request
    if (nil ~= t_24_) then
      t_24_ = t_24_["draft?"]
    else
    end
    _25_ = t_24_
  end
  if _25_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style
  local _29_
  do
    local t_28_ = pull_request
    if (nil ~= t_28_) then
      t_28_ = t_28_["draft?"]
    else
    end
    _29_ = t_28_
  end
  if _29_ then
    style = draft_style
  else
    local _32_
    do
      local t_31_ = pull_request
      if (nil ~= t_31_) then
        t_31_ = t_31_.mergeable
      else
      end
      _32_ = t_31_
    end
    if (_32_ == "CONFLICTING") then
      style = conflict_style
    else
      style = ci_style
    end
  end
  return hs.styledtext.new((emoji .. text), style)
end
local function get_menu_line(pull_request)
  local function _35_()
    local function _37_()
      local t_36_ = pull_request
      if (nil ~= t_36_) then
        t_36_ = t_36_.url
      else
      end
      return t_36_
    end
    return hs.urlevent.openURL(_37_())
  end
  return {title = get_title(pull_request), fn = _35_}
end
local function get_last_update_text()
  if state["last-update"] then
    return ("Last update: " .. os.date("%Y-%m-%d %H:%M:%S", state["last-update"]))
  else
    return "Last update: never"
  end
end
local function get_menu_table(list_of_pull_requests)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  local reload_line
  local function _40_()
    return hs.reload()
  end
  reload_line = {title = "\240\159\148\132 Reload Hammerspoon", fn = _40_}
  local last_update_line = {title = hs.styledtext.new(get_last_update_text(), empty_style), disabled = true}
  for i, pull_requests in ipairs(list_of_pull_requests) do
    if (i > 1) then
      table.insert(menu_table, separator)
    else
    end
    if (#pull_requests > 0) then
      for _, pull_request in ipairs(pull_requests) do
        table.insert(menu_table, get_menu_line(pull_request))
      end
    else
      table.insert(menu_table, empty_block)
    end
  end
  table.insert(menu_table, separator)
  table.insert(menu_table, reload_line)
  table.insert(menu_table, last_update_line)
  return menu_table
end
local function review_requested_3f(node)
  local _44_
  do
    local t_43_ = node
    if (nil ~= t_43_) then
      t_43_ = t_43_.reviewRequests
    else
    end
    if (nil ~= t_43_) then
      t_43_ = t_43_.nodes
    else
    end
    _44_ = t_43_
  end
  local function _47_(_241)
    local _49_
    do
      local t_48_ = _241
      if (nil ~= t_48_) then
        t_48_ = t_48_.requestedReviewer
      else
      end
      if (nil ~= t_48_) then
        t_48_ = t_48_.login
      else
      end
      _49_ = t_48_
    end
    return (_49_ == obj.username)
  end
  return hs.fnutils.some(_44_, _47_)
end
local function assignee_3f(node)
  local _53_
  do
    local t_52_ = node
    if (nil ~= t_52_) then
      t_52_ = t_52_.assignees
    else
    end
    if (nil ~= t_52_) then
      t_52_ = t_52_.nodes
    else
    end
    _53_ = t_52_
  end
  local function _56_(_241)
    local _58_
    do
      local t_57_ = _241
      if (nil ~= t_57_) then
        t_57_ = t_57_.login
      else
      end
      _58_ = t_57_
    end
    return (_58_ == obj.username)
  end
  return hs.fnutils.some(_53_, _56_)
end
local function get_pull_request(node)
  local _61_
  do
    local t_60_ = node
    if (nil ~= t_60_) then
      t_60_ = t_60_.title
    else
    end
    _61_ = t_60_
  end
  local _64_
  do
    local t_63_ = node
    if (nil ~= t_63_) then
      t_63_ = t_63_.url
    else
    end
    _64_ = t_63_
  end
  local _67_
  do
    local t_66_ = node
    if (nil ~= t_66_) then
      t_66_ = t_66_.isDraft
    else
    end
    _67_ = t_66_
  end
  local _70_
  do
    local t_69_ = node
    if (nil ~= t_69_) then
      t_69_ = t_69_.reviewDecision
    else
    end
    _70_ = t_69_
  end
  local _73_
  do
    local t_72_ = node
    if (nil ~= t_72_) then
      t_72_ = t_72_.mergeable
    else
    end
    _73_ = t_72_
  end
  local _76_
  do
    local t_75_ = node
    if (nil ~= t_75_) then
      t_75_ = t_75_.commits
    else
    end
    if (nil ~= t_75_) then
      t_75_ = t_75_.nodes
    else
    end
    if (nil ~= t_75_) then
      t_75_ = t_75_[1]
    else
    end
    if (nil ~= t_75_) then
      t_75_ = t_75_.commit
    else
    end
    if (nil ~= t_75_) then
      t_75_ = t_75_.statusCheckRollup
    else
    end
    if (nil ~= t_75_) then
      t_75_ = t_75_.state
    else
    end
    _76_ = t_75_
  end
  local _84_
  do
    local t_83_ = node
    if (nil ~= t_83_) then
      t_83_ = t_83_.author
    else
    end
    if (nil ~= t_83_) then
      t_83_ = t_83_.login
    else
    end
    _84_ = t_83_
  end
  return {title = _61_, url = _64_, ["draft?"] = _67_, ["review-requested?"] = review_requested_3f(node), ["review-decision"] = _70_, mergeable = _73_, ["ci-status"] = _76_, author = _84_, ["assignee?"] = assignee_3f(node)}
end
local function split_pull_requests(pull_requests)
  local review_3f
  local function _87_(_241)
    local t_88_ = _241
    if (nil ~= t_88_) then
      t_88_ = t_88_["review-requested?"]
    else
    end
    return t_88_
  end
  review_3f = _87_
  local user_3f
  local function _90_(_241)
    local _92_
    do
      local t_91_ = _241
      if (nil ~= t_91_) then
        t_91_ = t_91_.author
      else
      end
      _92_ = t_91_
    end
    local or_94_ = (_92_ == obj.username)
    if not or_94_ then
      local _96_
      do
        local t_95_ = _241
        if (nil ~= t_95_) then
          t_95_ = t_95_["assignee?"]
        else
        end
        _96_ = t_95_
      end
      or_94_ = (_96_ and not review_3f(_241))
    end
    return or_94_
  end
  user_3f = _90_
  local user = {}
  local reviews = {}
  local involved = {}
  for _, pull_request in ipairs(pull_requests) do
    if user_3f(pull_request) then
      table.insert(user, pull_request)
    elseif review_3f(pull_request) then
      table.insert(reviews, pull_request)
    else
      table.insert(involved, pull_request)
    end
  end
  return {user, reviews, involved}
end
local function callback(_, body, _0)
  local pull_requests
  local _99_
  if (nil ~= body) then
    local tmp_3_ = hs.json.decode(body)
    if (nil ~= tmp_3_) then
      local tmp_3_0
      do
        local t_102_ = tmp_3_
        if (nil ~= t_102_) then
          t_102_ = t_102_.data
        else
        end
        if (nil ~= t_102_) then
          t_102_ = t_102_.search
        else
        end
        if (nil ~= t_102_) then
          t_102_ = t_102_.nodes
        else
        end
        tmp_3_0 = t_102_
      end
      if (nil ~= tmp_3_0) then
        _99_ = hs.fnutils.imap(tmp_3_0, get_pull_request)
      else
        _99_ = nil
      end
    else
      _99_ = nil
    end
  else
    _99_ = nil
  end
  pull_requests = (_99_ or {})
  if (#pull_requests == 0) then
    obj.logger.i(body)
    local _109_
    if (nil ~= body) then
      local tmp_3_ = hs.json.decode(body)
      if (nil ~= tmp_3_) then
        local t_111_ = tmp_3_
        if (nil ~= t_111_) then
          t_111_ = t_111_.errors
        else
        end
        _109_ = t_111_
      else
        _109_ = nil
      end
    else
      _109_ = nil
    end
    if _109_ then
      return show_error("GraphQL query returned errors")
    else
      return nil
    end
  else
    local total_count = #pull_requests
    local menu_title = get_menu_title(total_count)
    local pull_request_blocks = split_pull_requests(pull_requests)
    local menu_table = get_menu_table(pull_request_blocks)
    obj.menuItem:setTitle(menu_title)
    return obj.menuItem:setMenu(menu_table)
  end
end
local function update()
  state["last-update"] = os.time()
  local headers = {["Content-Type"] = "application/json", Authorization = ("bearer " .. state.token)}
  local url = "https://api.github.com/graphql"
  local data = ("{\"query\": \"query ActivePullRequests($query: String!) { search(query: $query, type: ISSUE, first: 100) { nodes { ... on PullRequest { author { login } url title isDraft mergeable reviewDecision reviewRequests(first: 100) { nodes { requestedReviewer { ... on User { login } } } } assignees(first: 100) { nodes { login } } commits(last: 1) { nodes { commit { statusCheckRollup { state } } } } } } } }\", \"variables\": { \"query\": \"sort:updated-desc type:pr state:open involves:" .. obj.username .. "\" } }")
  return hs.http.asyncPost(url, data, headers, callback)
end
obj.init = function(self)
  self.logger = hs.logger.new("PullRequestGithub")
  self.menuItem = hs.menubar.new()
  do
    local icon = make_icon()
    self.menuItem:setIcon(icon, true)
  end
  state.token = fetch_token(self.skatePath, self.skateItem)
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  self.menuItem:setTitle("...")
  self.timer:start()
  self.timer:setNextTrigger(0)
  return self
end
obj.stop = function(self)
  self.timer:stop()
  self.menuItem:setTitle("...")
  self.menuItem:setMenu(nil)
  state["user-prs"] = {}
  state["review-prs"] = {}
  state["involved-prs"] = {}
  state.token = nil
  state["last-update"] = nil
  return self
end
return obj
