local obj = {}
obj.__index = obj
obj.name = "PullRequests"
obj.version = "1.0"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.username = nil
obj.keychainItem = nil
obj.unreadStyle = {color = {red = 1.0, green = 0.0, blue = 0.0, alpha = 1.0}}
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local function review_requested_3f(node)
  local _2_
  do
    local t_1_ = node
    if (nil ~= t_1_) then
      t_1_ = (t_1_).reviewRequests
    else
    end
    if (nil ~= t_1_) then
      t_1_ = (t_1_).nodes
    else
    end
    _2_ = t_1_
  end
  local function _5_(_241)
    local _7_
    do
      local t_6_ = _241
      if (nil ~= t_6_) then
        t_6_ = (t_6_).requestedReviewer
      else
      end
      if (nil ~= t_6_) then
        t_6_ = (t_6_).login
      else
      end
      _7_ = t_6_
    end
    return (_7_ == obj.username)
  end
  return hs.fnutils.some(_2_, _5_)
end
local function assignee_3f(node)
  local _11_
  do
    local t_10_ = node
    if (nil ~= t_10_) then
      t_10_ = (t_10_).assignees
    else
    end
    if (nil ~= t_10_) then
      t_10_ = (t_10_).nodes
    else
    end
    _11_ = t_10_
  end
  local function _14_(_241)
    local _16_
    do
      local t_15_ = _241
      if (nil ~= t_15_) then
        t_15_ = (t_15_).login
      else
      end
      _16_ = t_15_
    end
    return (_16_ == obj.username)
  end
  return hs.fnutils.some(_11_, _14_)
end
local function get_pull_request(node)
  local _19_
  do
    local t_18_ = node
    if (nil ~= t_18_) then
      t_18_ = (t_18_).title
    else
    end
    _19_ = t_18_
  end
  local _22_
  do
    local t_21_ = node
    if (nil ~= t_21_) then
      t_21_ = (t_21_).url
    else
    end
    _22_ = t_21_
  end
  local _25_
  do
    local t_24_ = node
    if (nil ~= t_24_) then
      t_24_ = (t_24_).isReadByViewer
    else
    end
    _25_ = t_24_
  end
  local _28_
  do
    local t_27_ = node
    if (nil ~= t_27_) then
      t_27_ = (t_27_).isDraft
    else
    end
    _28_ = t_27_
  end
  local _31_
  do
    local t_30_ = node
    if (nil ~= t_30_) then
      t_30_ = (t_30_).reviewDecision
    else
    end
    _31_ = t_30_
  end
  local _34_
  do
    local t_33_ = node
    if (nil ~= t_33_) then
      t_33_ = (t_33_).author
    else
    end
    if (nil ~= t_33_) then
      t_33_ = (t_33_).login
    else
    end
    _34_ = t_33_
  end
  return {title = _19_, url = _22_, ["unread?"] = not _25_, ["draft?"] = _28_, ["review-requested?"] = review_requested_3f(node), ["review-decision"] = _31_, author = _34_, ["assignee?"] = assignee_3f(node)}
end
local function get_menu_title(total_count, unread_3f)
  local style
  if unread_3f then
    style = obj.unreadStyle
  else
    style = {}
  end
  return hs.styledtext.new(("[PRs: " .. total_count .. "]"), style)
end
local function get_title(pull_request)
  local title
  do
    local t_38_ = pull_request
    if (nil ~= t_38_) then
      t_38_ = (t_38_).title
    else
    end
    title = t_38_
  end
  local text
  local _41_
  do
    local t_40_ = pull_request
    if (nil ~= t_40_) then
      t_40_ = (t_40_)["draft?"]
    else
    end
    _41_ = t_40_
  end
  if _41_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style
  local _45_
  do
    local t_44_ = pull_request
    if (nil ~= t_44_) then
      t_44_ = (t_44_)["unread?"]
    else
    end
    _45_ = t_44_
  end
  if _45_ then
    style = obj.unreadStyle
  else
    style = {}
  end
  return hs.styledtext.new(text, style)
end
local function get_menu_line(pull_request)
  local function _48_()
    local function _50_()
      local t_49_ = pull_request
      if (nil ~= t_49_) then
        t_49_ = (t_49_).url
      else
      end
      return t_49_
    end
    return hs.urlevent.openURL(_50_())
  end
  local _53_
  do
    local _52_
    do
      local t_54_ = pull_request
      if (nil ~= t_54_) then
        t_54_ = (t_54_)["review-decision"]
      else
      end
      _52_ = t_54_
    end
    if (_52_ == "CHANGES_REQUESTED") then
      _53_ = "mixed"
    elseif (_52_ == "APPROVED") then
      _53_ = "on"
    elseif true then
      local _ = _52_
      _53_ = "off"
    else
      _53_ = nil
    end
  end
  return {title = get_title(pull_request), fn = _48_, state = _53_}
end
local function get_menu_table(list_of_pull_requests)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  for i, pull_requests in ipairs(list_of_pull_requests) do
    if (i > 1) then
      table.insert(menu_table, separator)
    else
    end
    if (#pull_requests > 0) then
      for _, pull_request in ipairs(pull_requests) do
        table.insert(menu_table, get_menu_line(pull_request))
      end
    else
      table.insert(menu_table, empty_block)
    end
  end
  return menu_table
end
local function split_pull_requests(pull_requests)
  local review_3f
  local function _62_(_241)
    local t_63_ = _241
    if (nil ~= t_63_) then
      t_63_ = (t_63_)["review-requested?"]
    else
    end
    return t_63_
  end
  review_3f = _62_
  local user_3f
  local function _65_(_241)
    local _67_
    do
      local t_66_ = _241
      if (nil ~= t_66_) then
        t_66_ = (t_66_).author
      else
      end
      _67_ = t_66_
    end
    local function _70_()
      local t_69_ = _241
      if (nil ~= t_69_) then
        t_69_ = (t_69_)["assignee?"]
      else
      end
      return t_69_
    end
    return ((_67_ == obj.username) or (_70_() and not review_3f(_241)))
  end
  user_3f = _65_
  local user = {}
  local reviews = {}
  local involved = {}
  for _, pull_request in ipairs(pull_requests) do
    if user_3f(pull_request) then
      table.insert(user, pull_request)
    elseif review_3f(pull_request) then
      table.insert(reviews, pull_request)
    else
      table.insert(involved, pull_request)
    end
  end
  return {user, reviews, involved}
end
local function callback(_, body, _0)
  local pull_requests
  local function _74_()
    local _73_ = body
    if (nil ~= _73_) then
      local _75_ = hs.json.decode(_73_)
      if (nil ~= _75_) then
        local _76_
        do
          local t_77_ = _75_
          if (nil ~= t_77_) then
            t_77_ = (t_77_).data
          else
          end
          if (nil ~= t_77_) then
            t_77_ = (t_77_).search
          else
          end
          if (nil ~= t_77_) then
            t_77_ = (t_77_).nodes
          else
          end
          _76_ = t_77_
        end
        if (nil ~= _76_) then
          return hs.fnutils.imap(_76_, get_pull_request)
        else
          return _76_
        end
      else
        return _75_
      end
    else
      return _73_
    end
  end
  pull_requests = (_74_() or {})
  local total_count = #pull_requests
  local unread_3f
  local function _84_(_241)
    local t_85_ = _241
    if (nil ~= t_85_) then
      t_85_ = (t_85_)["unread?"]
    else
    end
    return t_85_
  end
  unread_3f = hs.fnutils.some(pull_requests, _84_)
  local menu_title = get_menu_title(total_count, unread_3f)
  local pull_request_blocks = split_pull_requests(pull_requests)
  local menu_table = get_menu_table(pull_request_blocks)
  if (#pull_requests == 0) then
    obj.logger.i(body)
  else
  end
  do end (obj.menuItem):setTitle(menu_title)
  return (obj.menuItem):setMenu(menu_table)
end
local function update()
  local keychain = require("keychain")
  local token = keychain["password-from-keychain"](obj.keychainItem)
  local headers = {["Content-Type"] = "application/json", Authorization = ("bearer " .. token)}
  local url = "https://api.github.com/graphql"
  local data = ("{\"query\": \"query ActivePullRequests($query: String!) { search(query: $query, type: ISSUE, first: 100) { nodes { ... on PullRequest { author { login } url title isReadByViewer isDraft reviewDecision reviewRequests(first: 100) { nodes { requestedReviewer { ... on User { login } } } } assignees(first: 100) { nodes { login } } } } } }\", \"variables\": { \"query\": \"sort:updated-desc type:pr state:open involves:" .. obj.username .. "\" } }")
  return hs.http.asyncPost(url, data, headers, callback)
end
obj.init = function(self)
  self.logger = hs.logger.new("PullRequests")
  self.menuItem = hs.menubar.new()
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  do end (self.menuItem):setTitle("[PRs: ...]")
  do end (self.timer):start()
  return self
end
obj.stop = function(self)
  do end (self.timer):stop()
  do end (self.menuItem):setTitle("[PRs: ...]")
  do end (self.menuItem):setMenu(nil)
  return self
end
return obj
