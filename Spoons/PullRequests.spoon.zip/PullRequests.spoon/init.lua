local obj = {}
obj.__index = obj
obj.name = "PullRequests"
obj.version = "1.0"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.username = nil
obj.keychainItem = nil
obj.unreadStyle = {color = {red = 1.0, green = 0.0, blue = 0.0, alpha = 1.0}}
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local function review_requested_3f(node)
  local _2_
  do
    local t_1_ = node
    if (nil ~= t_1_) then
      t_1_ = (t_1_).reviewRequests
    else
    end
    if (nil ~= t_1_) then
      t_1_ = (t_1_).nodes
    else
    end
    _2_ = t_1_
  end
  local function _5_(_241)
    local _7_
    do
      local t_6_ = _241
      if (nil ~= t_6_) then
        t_6_ = (t_6_).requestedReviewer
      else
      end
      if (nil ~= t_6_) then
        t_6_ = (t_6_).login
      else
      end
      _7_ = t_6_
    end
    return (_7_ == obj.username)
  end
  return hs.fnutils.some(_2_, _5_)
end
local function assignee_3f(node)
  local _11_
  do
    local t_10_ = node
    if (nil ~= t_10_) then
      t_10_ = (t_10_).assignees
    else
    end
    if (nil ~= t_10_) then
      t_10_ = (t_10_).nodes
    else
    end
    _11_ = t_10_
  end
  local function _14_(_241)
    local _16_
    do
      local t_15_ = _241
      if (nil ~= t_15_) then
        t_15_ = (t_15_).login
      else
      end
      _16_ = t_15_
    end
    return (_16_ == obj.username)
  end
  return hs.fnutils.some(_11_, _14_)
end
local function get_pull_request(node)
  local _19_
  do
    local t_18_ = node
    if (nil ~= t_18_) then
      t_18_ = (t_18_).title
    else
    end
    _19_ = t_18_
  end
  local _22_
  do
    local t_21_ = node
    if (nil ~= t_21_) then
      t_21_ = (t_21_).url
    else
    end
    _22_ = t_21_
  end
  local _25_
  do
    local t_24_ = node
    if (nil ~= t_24_) then
      t_24_ = (t_24_).isReadByViewer
    else
    end
    _25_ = t_24_
  end
  local _28_
  do
    local t_27_ = node
    if (nil ~= t_27_) then
      t_27_ = (t_27_).isDraft
    else
    end
    _28_ = t_27_
  end
  local _31_
  do
    local t_30_ = node
    if (nil ~= t_30_) then
      t_30_ = (t_30_).reviewDecision
    else
    end
    _31_ = t_30_
  end
  local _34_
  do
    local t_33_ = node
    if (nil ~= t_33_) then
      t_33_ = (t_33_).author
    else
    end
    if (nil ~= t_33_) then
      t_33_ = (t_33_).login
    else
    end
    _34_ = t_33_
  end
  do local _ = {title = _19_, url = _22_, ["unread?"] = not _25_, ["draft?"] = _28_, ["review-requested?"] = review_requested_3f(node), ["review-decision"] = _31_, author = _34_, ["assignee?"] = assignee_3f(node)} end
  local t_37_ = node
  if (nil ~= t_37_) then
    t_37_ = (t_37_).repository
  else
  end
  if (nil ~= t_37_) then
    t_37_ = (t_37_).name
  else
  end
  return t_37_
end
local function get_menu_title(total_count, unread_3f)
  local style
  if unread_3f then
    style = obj.unreadStyle
  else
    style = {}
  end
  return hs.styledtext.new(("[PRs: " .. total_count .. "]"), style)
end
local function get_title(pull_request)
  local title
  local function _42_()
    local t_41_ = pull_request
    if (nil ~= t_41_) then
      t_41_ = (t_41_).repository
    else
    end
    return t_41_
  end
  local function _45_()
    local t_44_ = pull_request
    if (nil ~= t_44_) then
      t_44_ = (t_44_).title
    else
    end
    return t_44_
  end
  title = ("[" .. _42_() .. "] " .. _45_())
  local text
  local _48_
  do
    local t_47_ = pull_request
    if (nil ~= t_47_) then
      t_47_ = (t_47_)["draft?"]
    else
    end
    _48_ = t_47_
  end
  if _48_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style
  local _52_
  do
    local t_51_ = pull_request
    if (nil ~= t_51_) then
      t_51_ = (t_51_)["unread?"]
    else
    end
    _52_ = t_51_
  end
  if _52_ then
    style = obj.unreadStyle
  else
    style = {}
  end
  return hs.styledtext.new(text, style)
end
local function get_menu_line(pull_request)
  local function _55_()
    local function _57_()
      local t_56_ = pull_request
      if (nil ~= t_56_) then
        t_56_ = (t_56_).url
      else
      end
      return t_56_
    end
    return hs.urlevent.openURL(_57_())
  end
  local _60_
  do
    local _59_
    do
      local t_61_ = pull_request
      if (nil ~= t_61_) then
        t_61_ = (t_61_)["review-decision"]
      else
      end
      _59_ = t_61_
    end
    if (_59_ == "CHANGES_REQUESTED") then
      _60_ = "mixed"
    elseif (_59_ == "APPROVED") then
      _60_ = "on"
    elseif true then
      local _ = _59_
      _60_ = "off"
    else
      _60_ = nil
    end
  end
  return {title = get_title(pull_request), fn = _55_, state = _60_}
end
local function get_menu_table(list_of_pull_requests)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  for i, pull_requests in ipairs(list_of_pull_requests) do
    if (i > 1) then
      table.insert(menu_table, separator)
    else
    end
    if (#pull_requests > 0) then
      for _, pull_request in ipairs(pull_requests) do
        table.insert(menu_table, get_menu_line(pull_request))
      end
    else
      table.insert(menu_table, empty_block)
    end
  end
  return menu_table
end
local function split_pull_requests(pull_requests)
  local review_3f
  local function _69_(_241)
    local t_70_ = _241
    if (nil ~= t_70_) then
      t_70_ = (t_70_)["review-requested?"]
    else
    end
    return t_70_
  end
  review_3f = _69_
  local user_3f
  local function _72_(_241)
    local _74_
    do
      local t_73_ = _241
      if (nil ~= t_73_) then
        t_73_ = (t_73_).author
      else
      end
      _74_ = t_73_
    end
    local function _76_()
      local t_77_ = _241
      if (nil ~= t_77_) then
        t_77_ = (t_77_)["assignee?"]
      else
      end
      return t_77_
    end
    return ((_74_ == obj.username) or (_76_() and not review_3f(_241)))
  end
  user_3f = _72_
  local user = {}
  local reviews = {}
  local involved = {}
  for _, pull_request in ipairs(pull_requests) do
    if user_3f(pull_request) then
      table.insert(user, pull_request)
    elseif review_3f(pull_request) then
      table.insert(reviews, pull_request)
    else
      table.insert(involved, pull_request)
    end
  end
  return {user, reviews, involved}
end
local function callback(_, body, _0)
  local pull_requests
  local function _80_()
    local _81_ = body
    if (nil ~= _81_) then
      local _82_ = hs.json.decode(_81_)
      if (nil ~= _82_) then
        local _83_
        do
          local t_84_ = _82_
          if (nil ~= t_84_) then
            t_84_ = (t_84_).data
          else
          end
          if (nil ~= t_84_) then
            t_84_ = (t_84_).search
          else
          end
          if (nil ~= t_84_) then
            t_84_ = (t_84_).nodes
          else
          end
          _83_ = t_84_
        end
        if (nil ~= _83_) then
          return hs.fnutils.imap(_83_, get_pull_request)
        else
          return _83_
        end
      else
        return _82_
      end
    else
      return _81_
    end
  end
  pull_requests = (_80_() or {})
  local total_count = #pull_requests
  local unread_3f
  local function _91_(_241)
    local t_92_ = _241
    if (nil ~= t_92_) then
      t_92_ = (t_92_)["unread?"]
    else
    end
    return t_92_
  end
  unread_3f = hs.fnutils.some(pull_requests, _91_)
  local menu_title = get_menu_title(total_count, unread_3f)
  local pull_request_blocks = split_pull_requests(pull_requests)
  local menu_table = get_menu_table(pull_request_blocks)
  if (#pull_requests == 0) then
    obj.logger.i(body)
  else
  end
  do end (obj.menuItem):setTitle(menu_title)
  return (obj.menuItem):setMenu(menu_table)
end
package.preload["keychain"] = package.preload["keychain"] or function(...)
  local function get_command(name)
    return ("/usr/bin/security find-generic-password -wa " .. name)
  end
  local function run_command(command)
    local handle = io.popen(command)
    local function close_handlers_8_auto(ok_9_auto, ...)
      handle:close()
      if ok_9_auto then
        return ...
      else
        return error(..., 0)
      end
    end
    local function _96_()
      return handle:read("*a")
    end
    return close_handlers_8_auto(_G.xpcall(_96_, (package.loaded.fennel or debug).traceback))
  end
  local function extract_password(text)
    return text:gsub("^%s*(.-)%s*$", "%1")
  end
  local function password_from_keychain(name)
    return extract_password(run_command(get_command(name)))
  end
  return {["password-from-keychain"] = password_from_keychain}
end
local function update()
  local keychain = require("keychain")
  local token = keychain["password-from-keychain"](obj.keychainItem)
  local headers = {["Content-Type"] = "application/json", Authorization = ("bearer " .. token)}
  local url = "https://api.github.com/graphql"
  local data = ("{\"query\": \"query ActivePullRequests($query: String!) { " .. "search(query: $query, type: ISSUE, first: 100) { " .. "nodes { ... on PullRequest { " .. "url title isReadByViewer isDraft reviewDecision " .. "author { login } " .. "repository { name } " .. "reviewRequests(first: 100) { nodes { requestedReviewer { ... on User { login } } } } " .. "assignees(first: 100) { nodes { login } } " .. "} } } }\", " .. "\"variables\": { \"query\": \"sort:updated-desc type:pr state:open involves:" .. obj.username .. "\" } }")
  return hs.http.asyncPost(url, data, headers, callback)
end
obj.init = function(self)
  self.logger = hs.logger.new("PullRequests")
  self.menuItem = hs.menubar.new()
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  do end (self.menuItem):setTitle("[PRs: ...]")
  do end (self.timer):setNextTrigger(0)
  return self
end
obj.stop = function(self)
  do end (self.timer):stop()
  do end (self.menuItem):setTitle("[PRs: ...]")
  do end (self.menuItem):setMenu(nil)
  return self
end
return obj
