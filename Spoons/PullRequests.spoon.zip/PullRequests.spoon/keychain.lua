local function get_command(name)
  return ("/usr/bin/security 2>&1 >/dev/null find-generic-password -ga " .. name .. " | sed -En '/^password: / s,^password: \"(.*)\"$,\\1,p'")
end
local function run_command(command)
  local handle = io.popen(command)
  local function close_handlers_8_auto(ok_9_auto, ...)
    handle:close()
    if ok_9_auto then
      return ...
    else
      return error(..., 0)
    end
  end
  local function _2_()
    return handle:read("*a")
  end
  return close_handlers_8_auto(_G.xpcall(_2_, (package.loaded.fennel or debug).traceback))
end
local function extract_password(text)
  return text:gsub("^%s*(.-)%s*$", "%1")
end
local function password_from_keychain(name)
  return extract_password(run_command(get_command(name)))
end
return {["password-from-keychain"] = password_from_keychain}
