local obj = {}
obj.__index = obj
obj.name = "GHADOPullRequest"
obj.version = "1.0"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.username = nil
obj.skateItem = nil
obj.skatePath = "/opt/homebrew/bin/skate"
obj.organizationUrl = nil
obj.project = nil
obj.userEmail = nil
obj.azPath = "/opt/homebrew/bin/az"
obj.ignoredRepos = {}
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local function fetch_token(skatePath, skateItem)
  local command = (skatePath .. " get " .. skateItem)
  local handle = io.popen(command)
  local function close_handlers_13_(ok_14_, ...)
    handle:close()
    if ok_14_ then
      return ...
    else
      return error(..., 0)
    end
  end
  local function _2_()
    local output = handle:read("*a")
    return output:gsub("^%s*(.-)%s*$", "%1")
  end
  local _4_
  do
    local t_3_ = _G
    if (nil ~= t_3_) then
      t_3_ = t_3_.package
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.loaded
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.fennel
    else
    end
    _4_ = t_3_
  end
  local or_8_ = _4_ or _G.debug
  if not or_8_ then
    local function _9_()
      return ""
    end
    or_8_ = {traceback = _9_}
  end
  return close_handlers_13_(_G.xpcall(_2_, or_8_.traceback))
end
local state = {["github-user-prs"] = {}, ["github-review-prs"] = {}, ["github-involved-prs"] = {}, ["azure-creator-prs"] = {}, ["azure-reviewer-prs"] = {}, ["azure-ci-status"] = {}, token = nil, ["last-update"] = nil}
local function make_icon()
  local ascii = "ASCII:\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . . . . . . . . . . . . . .\n. . 1 . . . 1 . . . 8 . . . 8 . .\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . 2 . . . . . . . 7 . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 4 . . 5 . . . 6 . . . . .\n. . . . 2 . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . 3 . . . 3 . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . ."
  local context = {{strokeColor = {red = 1, green = 1, blue = 1, alpha = 1}, fillColor = {alpha = 0}, lineWidth = 1.2, shouldClose = false}}
  return hs.image.imageFromASCII(ascii, context)
end
local function get_menu_title(total_count)
  return hs.styledtext.new(tostring(total_count))
end
local function get_error_title()
  local error_style = {color = {red = 1.0, green = 0, blue = 0, alpha = 1.0}}
  return hs.styledtext.new("error", error_style)
end
local function show_error(error_message)
  obj.logger.e(error_message)
  obj.menuItem:setTitle(get_error_title())
  return obj.menuItem:setMenu(nil)
end
local function get_last_update_text()
  if state["last-update"] then
    return ("Last update: " .. os.date("%Y-%m-%d %H:%M:%S", state["last-update"]))
  else
    return "Last update: never"
  end
end
local function get_title(pull_request)
  local title
  do
    local t_11_ = pull_request
    if (nil ~= t_11_) then
      t_11_ = t_11_.title
    else
    end
    title = t_11_
  end
  local source_prefix
  local _14_
  do
    local t_13_ = pull_request
    if (nil ~= t_13_) then
      t_13_ = t_13_.source
    else
    end
    _14_ = t_13_
  end
  if (_14_ == "github") then
    source_prefix = "[GH] "
  else
    source_prefix = "[ADO] "
  end
  local emoji
  do
    local t_17_ = pull_request
    if (nil ~= t_17_) then
      t_17_ = t_17_["status-emoji"]
    else
    end
    emoji = t_17_
  end
  local draft_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local text
  local _20_
  do
    local t_19_ = pull_request
    if (nil ~= t_19_) then
      t_19_ = t_19_["draft?"]
    else
    end
    _20_ = t_19_
  end
  if _20_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style
  local _24_
  do
    local t_23_ = pull_request
    if (nil ~= t_23_) then
      t_23_ = t_23_["draft?"]
    else
    end
    _24_ = t_23_
  end
  if _24_ then
    style = draft_style
  else
    local t_26_ = pull_request
    if (nil ~= t_26_) then
      t_26_ = t_26_.style
    else
    end
    style = t_26_
  end
  return hs.styledtext.new((source_prefix .. emoji .. text), style)
end
local function get_menu_line(pull_request)
  local function _29_()
    local function _31_()
      local t_30_ = pull_request
      if (nil ~= t_30_) then
        t_30_ = t_30_.url
      else
      end
      return t_30_
    end
    return hs.urlevent.openURL(_31_())
  end
  return {title = get_title(pull_request), fn = _29_}
end
local update_menu = nil
local function get_menu_table(list_of_pull_requests)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  local reload_line
  local function _33_()
    return hs.reload()
  end
  reload_line = {title = "\240\159\148\132 Reload Hammerspoon", fn = _33_}
  local last_update_line = {title = hs.styledtext.new(get_last_update_text(), empty_style), disabled = true}
  for i, pull_requests in ipairs(list_of_pull_requests) do
    if (i > 1) then
      table.insert(menu_table, separator)
    else
    end
    if (#pull_requests > 0) then
      for _, pull_request in ipairs(pull_requests) do
        table.insert(menu_table, get_menu_line(pull_request))
      end
    else
      table.insert(menu_table, empty_block)
    end
  end
  table.insert(menu_table, separator)
  table.insert(menu_table, reload_line)
  table.insert(menu_table, last_update_line)
  return menu_table
end
local function github_get_status_emoji(pull_request)
  local _37_
  do
    local t_36_ = pull_request
    if (nil ~= t_36_) then
      t_36_ = t_36_.mergeable
    else
    end
    _37_ = t_36_
  end
  if (_37_ == "CONFLICTING") then
    return "\226\154\148\239\184\143 "
  else
    local case_39_
    do
      local t_40_ = pull_request
      if (nil ~= t_40_) then
        t_40_ = t_40_["review-decision"]
      else
      end
      case_39_ = t_40_
    end
    if (case_39_ == "APPROVED") then
      return "\226\156\133 "
    elseif (case_39_ == "CHANGES_REQUESTED") then
      return "\226\157\140 "
    else
      local _ = case_39_
      return "\226\143\179 "
    end
  end
end
local function github_get_ci_status_style(pull_request)
  local case_44_
  do
    local t_45_ = pull_request
    if (nil ~= t_45_) then
      t_45_ = t_45_["ci-status"]
    else
    end
    case_44_ = t_45_
  end
  if (case_44_ == "SUCCESS") then
    return {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
  elseif (case_44_ == "FAILURE") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  elseif (case_44_ == "ERROR") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  else
    local _ = case_44_
    return {}
  end
end
local function github_get_style(node)
  local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
  local _49_
  do
    local t_48_ = node
    if (nil ~= t_48_) then
      t_48_ = t_48_.mergeable
    else
    end
    _49_ = t_48_
  end
  if (_49_ == "CONFLICTING") then
    return conflict_style
  else
    return github_get_ci_status_style(node)
  end
end
local function review_requested_3f(node)
  local _53_
  do
    local t_52_ = node
    if (nil ~= t_52_) then
      t_52_ = t_52_.reviewRequests
    else
    end
    if (nil ~= t_52_) then
      t_52_ = t_52_.nodes
    else
    end
    _53_ = t_52_
  end
  local function _56_(_241)
    local _58_
    do
      local t_57_ = _241
      if (nil ~= t_57_) then
        t_57_ = t_57_.requestedReviewer
      else
      end
      if (nil ~= t_57_) then
        t_57_ = t_57_.login
      else
      end
      _58_ = t_57_
    end
    return (_58_ == obj.username)
  end
  return hs.fnutils.some(_53_, _56_)
end
local function assignee_3f(node)
  local _62_
  do
    local t_61_ = node
    if (nil ~= t_61_) then
      t_61_ = t_61_.assignees
    else
    end
    if (nil ~= t_61_) then
      t_61_ = t_61_.nodes
    else
    end
    _62_ = t_61_
  end
  local function _65_(_241)
    local _67_
    do
      local t_66_ = _241
      if (nil ~= t_66_) then
        t_66_ = t_66_.login
      else
      end
      _67_ = t_66_
    end
    return (_67_ == obj.username)
  end
  return hs.fnutils.some(_62_, _65_)
end
local function normalize_github_pr(node)
  local _70_
  do
    local t_69_ = node
    if (nil ~= t_69_) then
      t_69_ = t_69_.title
    else
    end
    _70_ = t_69_
  end
  local _73_
  do
    local t_72_ = node
    if (nil ~= t_72_) then
      t_72_ = t_72_.url
    else
    end
    _73_ = t_72_
  end
  local _76_
  do
    local t_75_ = node
    if (nil ~= t_75_) then
      t_75_ = t_75_.isDraft
    else
    end
    _76_ = t_75_
  end
  local _79_
  do
    local t_78_ = node
    if (nil ~= t_78_) then
      t_78_ = t_78_.reviewDecision
    else
    end
    _79_ = t_78_
  end
  local _82_
  do
    local t_81_ = node
    if (nil ~= t_81_) then
      t_81_ = t_81_.mergeable
    else
    end
    _82_ = t_81_
  end
  local _85_
  do
    local t_84_ = node
    if (nil ~= t_84_) then
      t_84_ = t_84_.commits
    else
    end
    if (nil ~= t_84_) then
      t_84_ = t_84_.nodes
    else
    end
    if (nil ~= t_84_) then
      t_84_ = t_84_[1]
    else
    end
    if (nil ~= t_84_) then
      t_84_ = t_84_.commit
    else
    end
    if (nil ~= t_84_) then
      t_84_ = t_84_.statusCheckRollup
    else
    end
    if (nil ~= t_84_) then
      t_84_ = t_84_.state
    else
    end
    _85_ = t_84_
  end
  local _93_
  do
    local t_92_ = node
    if (nil ~= t_92_) then
      t_92_ = t_92_.author
    else
    end
    if (nil ~= t_92_) then
      t_92_ = t_92_.login
    else
    end
    _93_ = t_92_
  end
  return {title = _70_, url = _73_, ["draft?"] = _76_, source = "github", ["status-emoji"] = github_get_status_emoji(node), style = github_get_style(node), ["review-requested?"] = review_requested_3f(node), ["review-decision"] = _79_, mergeable = _82_, ["ci-status"] = _85_, author = _93_, ["assignee?"] = assignee_3f(node)}
end
local function split_github_pull_requests(pull_requests)
  local review_3f
  local function _96_(_241)
    local t_97_ = _241
    if (nil ~= t_97_) then
      t_97_ = t_97_["review-requested?"]
    else
    end
    return t_97_
  end
  review_3f = _96_
  local user_3f
  local function _99_(_241)
    local _101_
    do
      local t_100_ = _241
      if (nil ~= t_100_) then
        t_100_ = t_100_.author
      else
      end
      _101_ = t_100_
    end
    local or_103_ = (_101_ == obj.username)
    if not or_103_ then
      local _105_
      do
        local t_104_ = _241
        if (nil ~= t_104_) then
          t_104_ = t_104_["assignee?"]
        else
        end
        _105_ = t_104_
      end
      or_103_ = (_105_ and not review_3f(_241))
    end
    return or_103_
  end
  user_3f = _99_
  local user = {}
  local reviews = {}
  local involved = {}
  for _, pull_request in ipairs(pull_requests) do
    if user_3f(pull_request) then
      table.insert(user, pull_request)
    elseif review_3f(pull_request) then
      table.insert(reviews, pull_request)
    else
      table.insert(involved, pull_request)
    end
  end
  return user, reviews, involved
end
local function github_callback(_, body, _0)
  local pull_requests
  local _108_
  if (nil ~= body) then
    local tmp_3_ = hs.json.decode(body)
    if (nil ~= tmp_3_) then
      local tmp_3_0
      do
        local t_111_ = tmp_3_
        if (nil ~= t_111_) then
          t_111_ = t_111_.data
        else
        end
        if (nil ~= t_111_) then
          t_111_ = t_111_.search
        else
        end
        if (nil ~= t_111_) then
          t_111_ = t_111_.nodes
        else
        end
        tmp_3_0 = t_111_
      end
      if (nil ~= tmp_3_0) then
        _108_ = hs.fnutils.imap(tmp_3_0, normalize_github_pr)
      else
        _108_ = nil
      end
    else
      _108_ = nil
    end
  else
    _108_ = nil
  end
  pull_requests = (_108_ or {})
  if (#pull_requests == 0) then
    obj.logger.i(body)
    local _118_
    if (nil ~= body) then
      local tmp_3_ = hs.json.decode(body)
      if (nil ~= tmp_3_) then
        local t_120_ = tmp_3_
        if (nil ~= t_120_) then
          t_120_ = t_120_.errors
        else
        end
        _118_ = t_120_
      else
        _118_ = nil
      end
    else
      _118_ = nil
    end
    if _118_ then
      return show_error("GraphQL query returned errors")
    else
      return nil
    end
  else
    local user, reviews, involved = split_github_pull_requests(pull_requests)
    state["github-user-prs"] = user
    state["github-review-prs"] = reviews
    state["github-involved-prs"] = involved
    return update_menu()
  end
end
local function github_update()
  local headers = {["Content-Type"] = "application/json", Authorization = ("bearer " .. state.token)}
  local url = "https://api.github.com/graphql"
  local data = ("{\"query\": \"query ActivePullRequests($query: String!) { search(query: $query, type: ISSUE, first: 100) { nodes { ... on PullRequest { author { login } url title isDraft mergeable reviewDecision reviewRequests(first: 100) { nodes { requestedReviewer { ... on User { login } } } } assignees(first: 100) { nodes { login } } commits(last: 1) { nodes { commit { statusCheckRollup { state } } } } } } } }\", \"variables\": { \"query\": \"sort:updated-desc type:pr state:open involves:" .. obj.username .. "\" } }")
  return hs.http.asyncPost(url, data, headers, github_callback)
end
local function azure_get_status_emoji(pull_request)
  local case_126_
  do
    local t_127_ = pull_request
    if (nil ~= t_127_) then
      t_127_ = t_127_.mergeStatus
    else
    end
    case_126_ = t_127_
  end
  if (case_126_ == "succeeded") then
    return "\226\156\133 "
  elseif (case_126_ == "rejectedByPolicy") then
    return "\226\157\140 "
  elseif (case_126_ == "conflicts") then
    return "\226\154\148\239\184\143 "
  else
    local _ = case_126_
    return "\226\143\179 "
  end
end
local function azure_get_ci_status_style(pull_request)
  local pr_id
  do
    local t_130_ = pull_request
    if (nil ~= t_130_) then
      t_130_ = t_130_.id
    else
    end
    pr_id = t_130_
  end
  local ci_status = state["azure-ci-status"][pr_id]
  if (ci_status == "passed") then
    return {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
  elseif (ci_status == "failed") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  else
    local _ = ci_status
    return {}
  end
end
local function azure_get_style(pull_request)
  local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
  local _134_
  do
    local t_133_ = pull_request
    if (nil ~= t_133_) then
      t_133_ = t_133_.mergeStatus
    else
    end
    _134_ = t_133_
  end
  if (_134_ == "conflicts") then
    return conflict_style
  else
    return azure_get_ci_status_style(pull_request)
  end
end
local function get_pull_request_url(pr)
  local _138_
  do
    local t_137_ = pr
    if (nil ~= t_137_) then
      t_137_ = t_137_.repository
    else
    end
    _138_ = t_137_
  end
  local _141_
  do
    local t_140_ = pr
    if (nil ~= t_140_) then
      t_140_ = t_140_.id
    else
    end
    _141_ = t_140_
  end
  return (obj.organizationUrl .. obj.project .. "/_git/" .. _138_ .. "/pullrequest/" .. _141_)
end
local function normalize_azure_pr(pr)
  local _144_
  do
    local t_143_ = pr
    if (nil ~= t_143_) then
      t_143_ = t_143_.title
    else
    end
    _144_ = t_143_
  end
  local _147_
  do
    local t_146_ = pr
    if (nil ~= t_146_) then
      t_146_ = t_146_.isDraft
    else
    end
    _147_ = t_146_
  end
  local _150_
  do
    local t_149_ = pr
    if (nil ~= t_149_) then
      t_149_ = t_149_.id
    else
    end
    _150_ = t_149_
  end
  local _153_
  do
    local t_152_ = pr
    if (nil ~= t_152_) then
      t_152_ = t_152_.mergeStatus
    else
    end
    _153_ = t_152_
  end
  return {title = _144_, url = get_pull_request_url(pr), ["draft?"] = _147_, source = "azure", ["status-emoji"] = azure_get_status_emoji(pr), style = azure_get_style(pr), id = _150_, mergeStatus = _153_}
end
local function filter_ignored_repos(prs)
  if (#obj.ignoredRepos == 0) then
    return prs
  else
    local ignored
    do
      local tbl_21_ = {}
      for _, repo in ipairs(obj.ignoredRepos) do
        local k_22_, v_23_ = repo, true
        if ((k_22_ ~= nil) and (v_23_ ~= nil)) then
          tbl_21_[k_22_] = v_23_
        else
        end
      end
      ignored = tbl_21_
    end
    local tbl_26_ = {}
    local i_27_ = 0
    for _, pr in ipairs(prs) do
      local val_28_
      local _157_
      do
        local t_156_ = pr
        if (nil ~= t_156_) then
          t_156_ = t_156_.repository
        else
        end
        _157_ = t_156_
      end
      if not ignored[_157_] then
        val_28_ = pr
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    return tbl_26_
  end
end
local function parse_pr_response(json_output)
  local prs = (hs.json.decode(json_output) or {})
  return prs
end
local function parse_ci_status(policies)
  local build_policies
  do
    local tbl_26_ = {}
    local i_27_ = 0
    for _, p in ipairs(policies) do
      local val_28_
      local _163_
      do
        local t_162_ = p
        if (nil ~= t_162_) then
          t_162_ = t_162_.configuration
        else
        end
        if (nil ~= t_162_) then
          t_162_ = t_162_.type
        else
        end
        if (nil ~= t_162_) then
          t_162_ = t_162_.displayName
        else
        end
        _163_ = t_162_
      end
      if (_163_ == "Build") then
        val_28_ = p
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    build_policies = tbl_26_
  end
  if (#build_policies == 0) then
    return nil
  else
    local has_rejected = false
    local all_approved = true
    for _, p in ipairs(build_policies) do
      local status
      do
        local t_169_ = p
        if (nil ~= t_169_) then
          t_169_ = t_169_.status
        else
        end
        status = t_169_
      end
      if (status == "rejected") then
        has_rejected = true
      else
      end
      if (status ~= "approved") then
        all_approved = false
      else
      end
    end
    if has_rejected then
      return "failed"
    elseif all_approved then
      return "passed"
    else
      return nil
    end
  end
end
local function make_policy_callback(pr_id)
  local function _175_(exit_code, std_out, _std_err)
    if (exit_code == 0) then
      local policies = (hs.json.decode(std_out) or {})
      local ci_status = parse_ci_status(policies)
      state["azure-ci-status"][pr_id] = ci_status
      do
        local tbl_26_ = {}
        local i_27_ = 0
        for _, pr in ipairs(state["azure-creator-prs"]) do
          local val_28_
          local _177_
          do
            local t_176_ = pr
            if (nil ~= t_176_) then
              t_176_ = t_176_.id
            else
            end
            _177_ = t_176_
          end
          if (_177_ == pr_id) then
            local _179_
            do
              local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
              local _181_
              do
                local t_180_ = pr
                if (nil ~= t_180_) then
                  t_180_ = t_180_.mergeStatus
                else
                end
                _181_ = t_180_
              end
              if (_181_ == "conflicts") then
                _179_ = conflict_style
              else
                if (ci_status == "passed") then
                  _179_ = {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
                elseif (ci_status == "failed") then
                  _179_ = {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
                else
                  local _0 = ci_status
                  _179_ = {}
                end
              end
            end
            pr["style"] = _179_
            val_28_ = pr
          else
            val_28_ = pr
          end
          if (nil ~= val_28_) then
            i_27_ = (i_27_ + 1)
            tbl_26_[i_27_] = val_28_
          else
          end
        end
        state["azure-creator-prs"] = tbl_26_
      end
      do
        local tbl_26_ = {}
        local i_27_ = 0
        for _, pr in ipairs(state["azure-reviewer-prs"]) do
          local val_28_
          local _191_
          do
            local t_190_ = pr
            if (nil ~= t_190_) then
              t_190_ = t_190_.id
            else
            end
            _191_ = t_190_
          end
          if (_191_ == pr_id) then
            local _193_
            do
              local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
              local _195_
              do
                local t_194_ = pr
                if (nil ~= t_194_) then
                  t_194_ = t_194_.mergeStatus
                else
                end
                _195_ = t_194_
              end
              if (_195_ == "conflicts") then
                _193_ = conflict_style
              else
                if (ci_status == "passed") then
                  _193_ = {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
                elseif (ci_status == "failed") then
                  _193_ = {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
                else
                  local _0 = ci_status
                  _193_ = {}
                end
              end
            end
            pr["style"] = _193_
            val_28_ = pr
          else
            val_28_ = pr
          end
          if (nil ~= val_28_) then
            i_27_ = (i_27_ + 1)
            tbl_26_[i_27_] = val_28_
          else
          end
        end
        state["azure-reviewer-prs"] = tbl_26_
      end
      return update_menu()
    else
      return nil
    end
  end
  return _175_
end
local function fetch_policy_status(pr_id)
  local args = {"repos", "pr", "policy", "list", "--id", tostring(pr_id), "--organization", obj.organizationUrl}
  local callback = make_policy_callback(pr_id)
  local task = hs.task.new(obj.azPath, callback, args)
  return task:start()
end
local function fetch_policy_status_for_prs(prs)
  for _, pr in ipairs(prs) do
    local pr_id
    do
      local t_205_ = pr
      if (nil ~= t_205_) then
        t_205_ = t_205_.id
      else
      end
      pr_id = t_205_
    end
    if pr_id then
      fetch_policy_status(pr_id)
    else
    end
  end
  return nil
end
local function azure_creator_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local raw_prs = filter_ignored_repos(parse_pr_response(std_out))
    local prs = hs.fnutils.imap(raw_prs, normalize_azure_pr)
    state["azure-creator-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch Azure creator PRs: " .. std_err))
  end
end
local function azure_reviewer_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local raw_prs = filter_ignored_repos(parse_pr_response(std_out))
    local prs = hs.fnutils.imap(raw_prs, normalize_azure_pr)
    state["azure-reviewer-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch Azure reviewer PRs: " .. std_err))
  end
end
local function fetch_creator_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--creator", obj.userEmail}
  local task = hs.task.new(obj.azPath, azure_creator_callback, args)
  return task:start()
end
local function fetch_reviewer_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--reviewer", obj.userEmail}
  local task = hs.task.new(obj.azPath, azure_reviewer_callback, args)
  return task:start()
end
local function azure_update()
  fetch_creator_prs()
  return fetch_reviewer_prs()
end
local function _210_()
  local user_prs
  do
    local combined = {}
    for _, pr in ipairs(state["github-user-prs"]) do
      table.insert(combined, pr)
    end
    for _, pr in ipairs(state["azure-creator-prs"]) do
      table.insert(combined, pr)
    end
    user_prs = combined
  end
  local review_prs
  do
    local combined = {}
    for _, pr in ipairs(state["github-review-prs"]) do
      table.insert(combined, pr)
    end
    for _, pr in ipairs(state["azure-reviewer-prs"]) do
      table.insert(combined, pr)
    end
    review_prs = combined
  end
  local involved_prs = state["github-involved-prs"]
  local total_count = (#user_prs + #review_prs + #involved_prs)
  local menu_title = get_menu_title(total_count)
  local menu_table = get_menu_table({user_prs, review_prs, involved_prs})
  obj.menuItem:setTitle(menu_title)
  return obj.menuItem:setMenu(menu_table)
end
update_menu = _210_
local function update()
  state["last-update"] = os.time()
  github_update()
  return azure_update()
end
obj.init = function(self)
  self.logger = hs.logger.new("GHADOPullRequest")
  self.menuItem = hs.menubar.new()
  do
    local icon = make_icon()
    self.menuItem:setIcon(icon, true)
  end
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  state.token = fetch_token(self.skatePath, self.skateItem)
  self.menuItem:setTitle("...")
  self.timer:start()
  self.timer:setNextTrigger(0)
  return self
end
obj.stop = function(self)
  self.timer:stop()
  self.menuItem:setTitle("...")
  self.menuItem:setMenu(nil)
  state["github-user-prs"] = {}
  state["github-review-prs"] = {}
  state["github-involved-prs"] = {}
  state["azure-creator-prs"] = {}
  state["azure-reviewer-prs"] = {}
  state["azure-ci-status"] = {}
  state.token = nil
  state["last-update"] = nil
  return self
end
return obj
