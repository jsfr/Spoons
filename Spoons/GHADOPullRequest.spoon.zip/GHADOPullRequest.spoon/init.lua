local obj = {}
obj.__index = obj
obj.name = "GHADOPullRequest"
obj.version = "1.2"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.username = nil
obj.skateItem = nil
obj.skatePath = "/opt/homebrew/bin/skate"
obj.organizationUrl = nil
obj.project = nil
obj.userEmail = nil
obj.azPath = "/opt/homebrew/bin/az"
obj.ignoredRepos = {}
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local function fetch_token(skatePath, skateItem)
  local command = (skatePath .. " get " .. skateItem)
  local handle = io.popen(command)
  local function close_handlers_13_(ok_14_, ...)
    handle:close()
    if ok_14_ then
      return ...
    else
      return error(..., 0)
    end
  end
  local function _2_()
    local output = handle:read("*a")
    return output:gsub("^%s*(.-)%s*$", "%1")
  end
  local _4_
  do
    local t_3_ = _G
    if (nil ~= t_3_) then
      t_3_ = t_3_.package
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.loaded
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.fennel
    else
    end
    _4_ = t_3_
  end
  local or_8_ = _4_ or _G.debug
  if not or_8_ then
    local function _9_()
      return ""
    end
    or_8_ = {traceback = _9_}
  end
  return close_handlers_13_(_G.xpcall(_2_, or_8_.traceback))
end
local state = {["github-user-prs"] = {}, ["github-review-prs"] = {}, ["github-involved-prs"] = {}, ["azure-creator-prs"] = {}, ["azure-reviewer-prs"] = {}, token = nil, ["last-update"] = nil}
local function make_icon()
  local ascii = "ASCII:\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . . . . . . . . . . . . . .\n. . 1 . . . 1 . . . 8 . . . 8 . .\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . 2 . . . . . . . 7 . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 4 . . 5 . . . 6 . . . . .\n. . . . 2 . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . 3 . . . 3 . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . ."
  local context = {{strokeColor = {red = 1, green = 1, blue = 1, alpha = 1}, fillColor = {alpha = 0}, lineWidth = 1.2, shouldClose = false}}
  return hs.image.imageFromASCII(ascii, context)
end
local function get_menu_title(total_count)
  return hs.styledtext.new(tostring(total_count))
end
local function get_error_title()
  local error_style = {color = {red = 1.0, green = 0, blue = 0, alpha = 1.0}}
  return hs.styledtext.new("error", error_style)
end
local function show_error(error_message)
  obj.logger.e(error_message)
  obj.menuItem:setTitle(get_error_title())
  return obj.menuItem:setMenu(nil)
end
local function get_last_update_text()
  if state["last-update"] then
    return ("Last update: " .. os.date("%Y-%m-%d %H:%M:%S", state["last-update"]))
  else
    return "Last update: never"
  end
end
local function get_icons(pr)
  local _12_
  do
    local t_11_ = pr
    if (nil ~= t_11_) then
      t_11_ = t_11_["draft?"]
    else
    end
    _12_ = t_11_
  end
  if _12_ then
    return ""
  else
    local ci_icon
    do
      local case_14_
      do
        local t_15_ = pr
        if (nil ~= t_15_) then
          t_15_ = t_15_["ci-status"]
        else
        end
        case_14_ = t_15_
      end
      if (case_14_ == "success") then
        ci_icon = "\226\156\133 "
      elseif (case_14_ == "failure") then
        ci_icon = "\226\157\140 "
      elseif (case_14_ == "running") then
        ci_icon = "\226\143\179 "
      else
        local _ = case_14_
        ci_icon = ""
      end
    end
    local review_icon
    do
      local case_18_
      do
        local t_19_ = pr
        if (nil ~= t_19_) then
          t_19_ = t_19_["review-status"]
        else
        end
        case_18_ = t_19_
      end
      if (case_18_ == "approved") then
        review_icon = "\240\159\145\141 "
      elseif (case_18_ == "rejected") then
        review_icon = "\240\159\145\142 "
      else
        local _ = case_18_
        review_icon = ""
      end
    end
    local conflict_icon
    local _23_
    do
      local t_22_ = pr
      if (nil ~= t_22_) then
        t_22_ = t_22_["has-conflicts?"]
      else
      end
      _23_ = t_22_
    end
    if _23_ then
      conflict_icon = "\226\154\148\239\184\143 "
    else
      conflict_icon = ""
    end
    return (ci_icon .. review_icon .. conflict_icon)
  end
end
local function get_style(pr)
  local _28_
  do
    local t_27_ = pr
    if (nil ~= t_27_) then
      t_27_ = t_27_["draft?"]
    else
    end
    _28_ = t_27_
  end
  if _28_ then
    return {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  else
    return {}
  end
end
local function get_title(pull_request)
  local title
  do
    local t_31_ = pull_request
    if (nil ~= t_31_) then
      t_31_ = t_31_.title
    else
    end
    title = t_31_
  end
  local icons = get_icons(pull_request)
  local text
  local _34_
  do
    local t_33_ = pull_request
    if (nil ~= t_33_) then
      t_33_ = t_33_["draft?"]
    else
    end
    _34_ = t_33_
  end
  if _34_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style = get_style(pull_request)
  return hs.styledtext.new((icons .. text), style)
end
local function get_menu_line(pull_request)
  local function _37_()
    local function _39_()
      local t_38_ = pull_request
      if (nil ~= t_38_) then
        t_38_ = t_38_.url
      else
      end
      return t_38_
    end
    return hs.urlevent.openURL(_39_())
  end
  return {title = get_title(pull_request), fn = _37_}
end
local update_menu = nil
local function get_menu_table(list_of_pull_requests)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  local reload_line
  local function _41_()
    return hs.reload()
  end
  reload_line = {title = "\240\159\148\132 Reload Hammerspoon", fn = _41_}
  local last_update_line = {title = hs.styledtext.new(get_last_update_text(), empty_style), disabled = true}
  for i, pull_requests in ipairs(list_of_pull_requests) do
    if (i > 1) then
      table.insert(menu_table, separator)
    else
    end
    if (#pull_requests > 0) then
      for _, pull_request in ipairs(pull_requests) do
        table.insert(menu_table, get_menu_line(pull_request))
      end
    else
      table.insert(menu_table, empty_block)
    end
  end
  table.insert(menu_table, separator)
  table.insert(menu_table, reload_line)
  table.insert(menu_table, last_update_line)
  return menu_table
end
local function review_requested_3f(node)
  local _45_
  do
    local t_44_ = node
    if (nil ~= t_44_) then
      t_44_ = t_44_.reviewRequests
    else
    end
    if (nil ~= t_44_) then
      t_44_ = t_44_.nodes
    else
    end
    _45_ = t_44_
  end
  local function _48_(_241)
    local _50_
    do
      local t_49_ = _241
      if (nil ~= t_49_) then
        t_49_ = t_49_.requestedReviewer
      else
      end
      if (nil ~= t_49_) then
        t_49_ = t_49_.login
      else
      end
      _50_ = t_49_
    end
    return (_50_ == obj.username)
  end
  return hs.fnutils.some(_45_, _48_)
end
local function assignee_3f(node)
  local _54_
  do
    local t_53_ = node
    if (nil ~= t_53_) then
      t_53_ = t_53_.assignees
    else
    end
    if (nil ~= t_53_) then
      t_53_ = t_53_.nodes
    else
    end
    _54_ = t_53_
  end
  local function _57_(_241)
    local _59_
    do
      local t_58_ = _241
      if (nil ~= t_58_) then
        t_58_ = t_58_.login
      else
      end
      _59_ = t_58_
    end
    return (_59_ == obj.username)
  end
  return hs.fnutils.some(_54_, _57_)
end
local function normalize_github_pr(node)
  local review_decision
  do
    local t_61_ = node
    if (nil ~= t_61_) then
      t_61_ = t_61_.reviewDecision
    else
    end
    review_decision = t_61_
  end
  local ci_state
  do
    local t_63_ = node
    if (nil ~= t_63_) then
      t_63_ = t_63_.commits
    else
    end
    if (nil ~= t_63_) then
      t_63_ = t_63_.nodes
    else
    end
    if (nil ~= t_63_) then
      t_63_ = t_63_[1]
    else
    end
    if (nil ~= t_63_) then
      t_63_ = t_63_.commit
    else
    end
    if (nil ~= t_63_) then
      t_63_ = t_63_.statusCheckRollup
    else
    end
    if (nil ~= t_63_) then
      t_63_ = t_63_.state
    else
    end
    ci_state = t_63_
  end
  local mergeable
  do
    local t_70_ = node
    if (nil ~= t_70_) then
      t_70_ = t_70_.mergeable
    else
    end
    mergeable = t_70_
  end
  local _73_
  do
    local t_72_ = node
    if (nil ~= t_72_) then
      t_72_ = t_72_.title
    else
    end
    _73_ = t_72_
  end
  local _76_
  do
    local t_75_ = node
    if (nil ~= t_75_) then
      t_75_ = t_75_.url
    else
    end
    _76_ = t_75_
  end
  local _79_
  do
    local t_78_ = node
    if (nil ~= t_78_) then
      t_78_ = t_78_.isDraft
    else
    end
    _79_ = t_78_
  end
  local _81_
  if (review_decision == "APPROVED") then
    _81_ = "approved"
  elseif (review_decision == "CHANGES_REQUESTED") then
    _81_ = "rejected"
  else
    local _ = review_decision
    _81_ = "pending"
  end
  local _86_
  if (ci_state == "SUCCESS") then
    _86_ = "success"
  elseif (ci_state == "FAILURE") then
    _86_ = "failure"
  elseif (ci_state == "ERROR") then
    _86_ = "failure"
  elseif (ci_state == "PENDING") then
    _86_ = "running"
  elseif (ci_state == "EXPECTED") then
    _86_ = "running"
  else
    local _ = ci_state
    _86_ = "none"
  end
  local _95_
  do
    local t_94_ = node
    if (nil ~= t_94_) then
      t_94_ = t_94_.author
    else
    end
    if (nil ~= t_94_) then
      t_94_ = t_94_.login
    else
    end
    _95_ = t_94_
  end
  return {title = _73_, url = _76_, ["draft?"] = _79_, source = "github", ["review-status"] = _81_, ["ci-status"] = _86_, ["has-conflicts?"] = (mergeable == "CONFLICTING"), ["review-requested?"] = review_requested_3f(node), author = _95_, ["assignee?"] = assignee_3f(node)}
end
local function split_github_pull_requests(pull_requests)
  local review_3f
  local function _98_(_241)
    local t_99_ = _241
    if (nil ~= t_99_) then
      t_99_ = t_99_["review-requested?"]
    else
    end
    return t_99_
  end
  review_3f = _98_
  local user_3f
  local function _101_(_241)
    local _103_
    do
      local t_102_ = _241
      if (nil ~= t_102_) then
        t_102_ = t_102_.author
      else
      end
      _103_ = t_102_
    end
    local or_105_ = (_103_ == obj.username)
    if not or_105_ then
      local _107_
      do
        local t_106_ = _241
        if (nil ~= t_106_) then
          t_106_ = t_106_["assignee?"]
        else
        end
        _107_ = t_106_
      end
      or_105_ = (_107_ and not review_3f(_241))
    end
    return or_105_
  end
  user_3f = _101_
  local user = {}
  local reviews = {}
  local involved = {}
  for _, pull_request in ipairs(pull_requests) do
    if user_3f(pull_request) then
      table.insert(user, pull_request)
    elseif review_3f(pull_request) then
      table.insert(reviews, pull_request)
    else
      table.insert(involved, pull_request)
    end
  end
  return user, reviews, involved
end
local function github_callback(_, body, _0)
  local pull_requests
  local _110_
  if (nil ~= body) then
    local tmp_3_ = hs.json.decode(body)
    if (nil ~= tmp_3_) then
      local tmp_3_0
      do
        local t_113_ = tmp_3_
        if (nil ~= t_113_) then
          t_113_ = t_113_.data
        else
        end
        if (nil ~= t_113_) then
          t_113_ = t_113_.search
        else
        end
        if (nil ~= t_113_) then
          t_113_ = t_113_.nodes
        else
        end
        tmp_3_0 = t_113_
      end
      if (nil ~= tmp_3_0) then
        _110_ = hs.fnutils.imap(tmp_3_0, normalize_github_pr)
      else
        _110_ = nil
      end
    else
      _110_ = nil
    end
  else
    _110_ = nil
  end
  pull_requests = (_110_ or {})
  if (#pull_requests == 0) then
    obj.logger.i(body)
    local _120_
    if (nil ~= body) then
      local tmp_3_ = hs.json.decode(body)
      if (nil ~= tmp_3_) then
        local t_122_ = tmp_3_
        if (nil ~= t_122_) then
          t_122_ = t_122_.errors
        else
        end
        _120_ = t_122_
      else
        _120_ = nil
      end
    else
      _120_ = nil
    end
    if _120_ then
      return show_error("GraphQL query returned errors")
    else
      return nil
    end
  else
    local user, reviews, involved = split_github_pull_requests(pull_requests)
    state["github-user-prs"] = user
    state["github-review-prs"] = reviews
    state["github-involved-prs"] = involved
    return update_menu()
  end
end
local function github_update()
  local headers = {["Content-Type"] = "application/json", Authorization = ("bearer " .. state.token)}
  local url = "https://api.github.com/graphql"
  local data = ("{\"query\": \"query ActivePullRequests($query: String!) { search(query: $query, type: ISSUE, first: 100) { nodes { ... on PullRequest { author { login } url title isDraft mergeable reviewDecision reviewRequests(first: 100) { nodes { requestedReviewer { ... on User { login } } } } assignees(first: 100) { nodes { login } } commits(last: 1) { nodes { commit { statusCheckRollup { state } } } } } } } }\", \"variables\": { \"query\": \"sort:updated-desc type:pr state:open involves:" .. obj.username .. "\" } }")
  return hs.http.asyncPost(url, data, headers, github_callback)
end
local function get_pull_request_url(pr)
  local _129_
  do
    local t_128_ = pr
    if (nil ~= t_128_) then
      t_128_ = t_128_.repository
    else
    end
    _129_ = t_128_
  end
  local _132_
  do
    local t_131_ = pr
    if (nil ~= t_131_) then
      t_131_ = t_131_.id
    else
    end
    _132_ = t_131_
  end
  return (obj.organizationUrl .. obj.project .. "/_git/" .. _129_ .. "/pullrequest/" .. _132_)
end
local function azure_get_review_status(pr)
  local votes
  local _135_
  do
    local t_134_ = pr
    if (nil ~= t_134_) then
      t_134_ = t_134_.reviewerVotes
    else
    end
    _135_ = t_134_
  end
  votes = (_135_ or {})
  local has_approval = false
  local has_rejection = false
  for _, vote in ipairs(votes) do
    if ((vote == -10) or (vote == -5)) then
      has_rejection = true
    else
    end
    if ((vote == 10) or (vote == 5)) then
      has_approval = true
    else
    end
  end
  if has_rejection then
    return "rejected"
  elseif has_approval then
    return "approved"
  else
    return "pending"
  end
end
local function normalize_azure_pr(pr)
  local _141_
  do
    local t_140_ = pr
    if (nil ~= t_140_) then
      t_140_ = t_140_.title
    else
    end
    _141_ = t_140_
  end
  local _144_
  do
    local t_143_ = pr
    if (nil ~= t_143_) then
      t_143_ = t_143_.isDraft
    else
    end
    _144_ = t_143_
  end
  local _147_
  do
    local t_146_ = pr
    if (nil ~= t_146_) then
      t_146_ = t_146_.mergeStatus
    else
    end
    _147_ = t_146_
  end
  local _150_
  do
    local t_149_ = pr
    if (nil ~= t_149_) then
      t_149_ = t_149_.id
    else
    end
    _150_ = t_149_
  end
  local _153_
  do
    local t_152_ = pr
    if (nil ~= t_152_) then
      t_152_ = t_152_.mergeStatus
    else
    end
    _153_ = t_152_
  end
  return {title = _141_, url = get_pull_request_url(pr), ["draft?"] = _144_, source = "azure", ["review-status"] = azure_get_review_status(pr), ["ci-status"] = "none", ["has-conflicts?"] = (_147_ == "conflicts"), id = _150_, mergeStatus = _153_}
end
local function filter_ignored_repos(prs)
  if (#obj.ignoredRepos == 0) then
    return prs
  else
    local ignored
    do
      local tbl_21_ = {}
      for _, repo in ipairs(obj.ignoredRepos) do
        local k_22_, v_23_ = repo, true
        if ((k_22_ ~= nil) and (v_23_ ~= nil)) then
          tbl_21_[k_22_] = v_23_
        else
        end
      end
      ignored = tbl_21_
    end
    local tbl_26_ = {}
    local i_27_ = 0
    for _, pr in ipairs(prs) do
      local val_28_
      local _157_
      do
        local t_156_ = pr
        if (nil ~= t_156_) then
          t_156_ = t_156_.repository
        else
        end
        _157_ = t_156_
      end
      if not ignored[_157_] then
        val_28_ = pr
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    return tbl_26_
  end
end
local function parse_pr_response(json_output)
  local prs = (hs.json.decode(json_output) or {})
  return prs
end
local function parse_ci_status(policies)
  local build_policies
  do
    local tbl_26_ = {}
    local i_27_ = 0
    for _, p in ipairs(policies) do
      local val_28_
      local _163_
      do
        local t_162_ = p
        if (nil ~= t_162_) then
          t_162_ = t_162_.configuration
        else
        end
        if (nil ~= t_162_) then
          t_162_ = t_162_.type
        else
        end
        if (nil ~= t_162_) then
          t_162_ = t_162_.displayName
        else
        end
        _163_ = t_162_
      end
      if (_163_ == "Build") then
        val_28_ = p
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    build_policies = tbl_26_
  end
  if (#build_policies == 0) then
    return "none"
  else
    local has_rejected = false
    local all_approved = true
    for _, p in ipairs(build_policies) do
      local status
      do
        local t_169_ = p
        if (nil ~= t_169_) then
          t_169_ = t_169_.status
        else
        end
        status = t_169_
      end
      if (status == "rejected") then
        has_rejected = true
      else
      end
      if (status ~= "approved") then
        all_approved = false
      else
      end
    end
    if has_rejected then
      return "failure"
    elseif all_approved then
      return "success"
    else
      return "running"
    end
  end
end
local function make_policy_callback(pr_id)
  local function _175_(exit_code, std_out, _std_err)
    if (exit_code == 0) then
      local policies = (hs.json.decode(std_out) or {})
      local ci_status = parse_ci_status(policies)
      for _, pr in ipairs(state["azure-creator-prs"]) do
        local _177_
        do
          local t_176_ = pr
          if (nil ~= t_176_) then
            t_176_ = t_176_.id
          else
          end
          _177_ = t_176_
        end
        if (_177_ == pr_id) then
          pr["ci-status"] = ci_status
        else
        end
      end
      for _, pr in ipairs(state["azure-reviewer-prs"]) do
        local _181_
        do
          local t_180_ = pr
          if (nil ~= t_180_) then
            t_180_ = t_180_.id
          else
          end
          _181_ = t_180_
        end
        if (_181_ == pr_id) then
          pr["ci-status"] = ci_status
        else
        end
      end
      return update_menu()
    else
      return nil
    end
  end
  return _175_
end
local function fetch_policy_status(pr_id)
  local args = {"repos", "pr", "policy", "list", "--id", tostring(pr_id), "--organization", obj.organizationUrl}
  local callback = make_policy_callback(pr_id)
  local task = hs.task.new(obj.azPath, callback, args)
  return task:start()
end
local function fetch_policy_status_for_prs(prs)
  for _, pr in ipairs(prs) do
    local pr_id
    do
      local t_185_ = pr
      if (nil ~= t_185_) then
        t_185_ = t_185_.id
      else
      end
      pr_id = t_185_
    end
    if pr_id then
      fetch_policy_status(pr_id)
    else
    end
  end
  return nil
end
local function azure_creator_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local raw_prs = filter_ignored_repos(parse_pr_response(std_out))
    local prs = hs.fnutils.imap(raw_prs, normalize_azure_pr)
    state["azure-creator-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch Azure creator PRs: " .. std_err))
  end
end
local function azure_reviewer_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local raw_prs = filter_ignored_repos(parse_pr_response(std_out))
    local prs = hs.fnutils.imap(raw_prs, normalize_azure_pr)
    state["azure-reviewer-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch Azure reviewer PRs: " .. std_err))
  end
end
local function fetch_creator_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus," .. "reviewerVotes: reviewers[].vote" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--creator", obj.userEmail}
  local task = hs.task.new(obj.azPath, azure_creator_callback, args)
  return task:start()
end
local function fetch_reviewer_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus," .. "reviewerVotes: reviewers[].vote" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--reviewer", obj.userEmail}
  local task = hs.task.new(obj.azPath, azure_reviewer_callback, args)
  return task:start()
end
local function azure_update()
  fetch_creator_prs()
  return fetch_reviewer_prs()
end
local function _190_()
  local user_prs
  do
    local combined = {}
    for _, pr in ipairs(state["github-user-prs"]) do
      table.insert(combined, pr)
    end
    for _, pr in ipairs(state["azure-creator-prs"]) do
      table.insert(combined, pr)
    end
    user_prs = combined
  end
  local review_prs
  do
    local combined = {}
    for _, pr in ipairs(state["github-review-prs"]) do
      table.insert(combined, pr)
    end
    for _, pr in ipairs(state["azure-reviewer-prs"]) do
      table.insert(combined, pr)
    end
    review_prs = combined
  end
  local involved_prs = state["github-involved-prs"]
  local total_count = (#user_prs + #review_prs + #involved_prs)
  local menu_title = get_menu_title(total_count)
  local menu_table = get_menu_table({user_prs, review_prs, involved_prs})
  obj.menuItem:setTitle(menu_title)
  return obj.menuItem:setMenu(menu_table)
end
update_menu = _190_
local function update()
  state["last-update"] = os.time()
  github_update()
  return azure_update()
end
obj.init = function(self)
  self.logger = hs.logger.new("GHADOPullRequest")
  self.menuItem = hs.menubar.new()
  do
    local icon = make_icon()
    self.menuItem:setIcon(icon, true)
  end
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  state.token = fetch_token(self.skatePath, self.skateItem)
  self.menuItem:setTitle("...")
  self.timer:start()
  self.timer:setNextTrigger(0)
  return self
end
obj.stop = function(self)
  self.timer:stop()
  self.menuItem:setTitle("...")
  self.menuItem:setMenu(nil)
  state["github-user-prs"] = {}
  state["github-review-prs"] = {}
  state["github-involved-prs"] = {}
  state["azure-creator-prs"] = {}
  state["azure-reviewer-prs"] = {}
  state.token = nil
  state["last-update"] = nil
  return self
end
return obj
