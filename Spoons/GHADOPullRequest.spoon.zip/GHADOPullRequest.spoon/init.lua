local obj = {}
obj.__index = obj
obj.name = "GHADOPullRequest"
obj.version = "1.2"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.username = nil
obj.skateItem = nil
obj.skatePath = "/opt/homebrew/bin/skate"
obj.organizationUrl = nil
obj.project = nil
obj.userEmail = nil
obj.azPath = "/opt/homebrew/bin/az"
obj.ignoredRepos = {}
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local function fetch_token(skatePath, skateItem)
  local command = (skatePath .. " get " .. skateItem)
  local handle = io.popen(command)
  local function close_handlers_13_(ok_14_, ...)
    handle:close()
    if ok_14_ then
      return ...
    else
      return error(..., 0)
    end
  end
  local function _2_()
    local output = handle:read("*a")
    return output:gsub("^%s*(.-)%s*$", "%1")
  end
  local _4_
  do
    local t_3_ = _G
    if (nil ~= t_3_) then
      t_3_ = t_3_.package
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.loaded
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.fennel
    else
    end
    _4_ = t_3_
  end
  local or_8_ = _4_ or _G.debug
  if not or_8_ then
    local function _9_()
      return ""
    end
    or_8_ = {traceback = _9_}
  end
  return close_handlers_13_(_G.xpcall(_2_, or_8_.traceback))
end
local state = {["github-user-prs"] = {}, ["github-review-prs"] = {}, ["github-involved-prs"] = {}, ["azure-creator-prs"] = {}, ["azure-reviewer-prs"] = {}, token = nil, ["last-update"] = nil}
local function make_icon()
  local ascii = "ASCII:\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . . . . . . . . . . . . . .\n. . 1 . . . 1 . . . 8 . . . 8 . .\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . 2 . . . . . . . 7 . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 4 . . 5 . . . 6 . . . . .\n. . . . 2 . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . 3 . . . 3 . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . ."
  local context = {{strokeColor = {red = 1, green = 1, blue = 1, alpha = 1}, fillColor = {alpha = 0}, lineWidth = 1.2, shouldClose = false}}
  return hs.image.imageFromASCII(ascii, context)
end
local function get_menu_title(total_count)
  return hs.styledtext.new(tostring(total_count))
end
local function get_error_title()
  local error_style = {color = {red = 1.0, green = 0, blue = 0, alpha = 1.0}}
  return hs.styledtext.new("error", error_style)
end
local function show_error(error_message)
  obj.logger.e(error_message)
  obj.menuItem:setTitle(get_error_title())
  return obj.menuItem:setMenu(nil)
end
local function get_last_update_text()
  if state["last-update"] then
    return ("Last update: " .. os.date("%Y-%m-%d %H:%M:%S", state["last-update"]))
  else
    return "Last update: never"
  end
end
local function get_icons(pr)
  local ci_icon
  local _12_
  do
    local t_11_ = pr
    if (nil ~= t_11_) then
      t_11_ = t_11_["draft?"]
    else
    end
    _12_ = t_11_
  end
  if _12_ then
    ci_icon = ""
  else
    local case_14_
    do
      local t_15_ = pr
      if (nil ~= t_15_) then
        t_15_ = t_15_["ci-status"]
      else
      end
      case_14_ = t_15_
    end
    if (case_14_ == "success") then
      ci_icon = "\226\156\133 "
    elseif (case_14_ == "failure") then
      ci_icon = "\226\157\140 "
    elseif (case_14_ == "running") then
      ci_icon = "\226\143\179 "
    else
      local _ = case_14_
      ci_icon = ""
    end
  end
  local conflict_icon
  local _20_
  do
    local t_19_ = pr
    if (nil ~= t_19_) then
      t_19_ = t_19_["has-conflicts?"]
    else
    end
    _20_ = t_19_
  end
  if _20_ then
    conflict_icon = "\226\154\148\239\184\143 "
  else
    conflict_icon = ""
  end
  return (ci_icon .. conflict_icon)
end
local function get_style(pr)
  local _24_
  do
    local t_23_ = pr
    if (nil ~= t_23_) then
      t_23_ = t_23_["draft?"]
    else
    end
    _24_ = t_23_
  end
  if _24_ then
    return {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  else
    local _27_
    do
      local t_26_ = pr
      if (nil ~= t_26_) then
        t_26_ = t_26_["review-status"]
      else
      end
      _27_ = t_26_
    end
    if (_27_ == "approved") then
      return {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
    else
      local _30_
      do
        local t_29_ = pr
        if (nil ~= t_29_) then
          t_29_ = t_29_["review-status"]
        else
        end
        _30_ = t_29_
      end
      if (_30_ == "rejected") then
        return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
      else
        return {}
      end
    end
  end
end
local function get_title(pull_request)
  local title
  do
    local t_33_ = pull_request
    if (nil ~= t_33_) then
      t_33_ = t_33_.title
    else
    end
    title = t_33_
  end
  local icons = get_icons(pull_request)
  local text
  local _36_
  do
    local t_35_ = pull_request
    if (nil ~= t_35_) then
      t_35_ = t_35_["draft?"]
    else
    end
    _36_ = t_35_
  end
  if _36_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style = get_style(pull_request)
  return hs.styledtext.new((icons .. text), style)
end
local function get_menu_line(pull_request)
  local function _39_()
    local function _41_()
      local t_40_ = pull_request
      if (nil ~= t_40_) then
        t_40_ = t_40_.url
      else
      end
      return t_40_
    end
    return hs.urlevent.openURL(_41_())
  end
  return {title = get_title(pull_request), fn = _39_}
end
local update_menu = nil
local function get_menu_table(list_of_pull_requests)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  local reload_line
  local function _43_()
    return hs.reload()
  end
  reload_line = {title = "\240\159\148\132 Reload Hammerspoon", fn = _43_}
  local last_update_line = {title = hs.styledtext.new(get_last_update_text(), empty_style), disabled = true}
  for i, pull_requests in ipairs(list_of_pull_requests) do
    if (i > 1) then
      table.insert(menu_table, separator)
    else
    end
    if (#pull_requests > 0) then
      for _, pull_request in ipairs(pull_requests) do
        table.insert(menu_table, get_menu_line(pull_request))
      end
    else
      table.insert(menu_table, empty_block)
    end
  end
  table.insert(menu_table, separator)
  table.insert(menu_table, reload_line)
  table.insert(menu_table, last_update_line)
  return menu_table
end
local function review_requested_3f(node)
  local _47_
  do
    local t_46_ = node
    if (nil ~= t_46_) then
      t_46_ = t_46_.reviewRequests
    else
    end
    if (nil ~= t_46_) then
      t_46_ = t_46_.nodes
    else
    end
    _47_ = t_46_
  end
  local function _50_(_241)
    local _52_
    do
      local t_51_ = _241
      if (nil ~= t_51_) then
        t_51_ = t_51_.requestedReviewer
      else
      end
      if (nil ~= t_51_) then
        t_51_ = t_51_.login
      else
      end
      _52_ = t_51_
    end
    return (_52_ == obj.username)
  end
  return hs.fnutils.some(_47_, _50_)
end
local function assignee_3f(node)
  local _56_
  do
    local t_55_ = node
    if (nil ~= t_55_) then
      t_55_ = t_55_.assignees
    else
    end
    if (nil ~= t_55_) then
      t_55_ = t_55_.nodes
    else
    end
    _56_ = t_55_
  end
  local function _59_(_241)
    local _61_
    do
      local t_60_ = _241
      if (nil ~= t_60_) then
        t_60_ = t_60_.login
      else
      end
      _61_ = t_60_
    end
    return (_61_ == obj.username)
  end
  return hs.fnutils.some(_56_, _59_)
end
local function normalize_github_pr(node)
  local review_decision
  do
    local t_63_ = node
    if (nil ~= t_63_) then
      t_63_ = t_63_.reviewDecision
    else
    end
    review_decision = t_63_
  end
  local ci_state
  do
    local t_65_ = node
    if (nil ~= t_65_) then
      t_65_ = t_65_.commits
    else
    end
    if (nil ~= t_65_) then
      t_65_ = t_65_.nodes
    else
    end
    if (nil ~= t_65_) then
      t_65_ = t_65_[1]
    else
    end
    if (nil ~= t_65_) then
      t_65_ = t_65_.commit
    else
    end
    if (nil ~= t_65_) then
      t_65_ = t_65_.statusCheckRollup
    else
    end
    if (nil ~= t_65_) then
      t_65_ = t_65_.state
    else
    end
    ci_state = t_65_
  end
  local mergeable
  do
    local t_72_ = node
    if (nil ~= t_72_) then
      t_72_ = t_72_.mergeable
    else
    end
    mergeable = t_72_
  end
  local _75_
  do
    local t_74_ = node
    if (nil ~= t_74_) then
      t_74_ = t_74_.title
    else
    end
    _75_ = t_74_
  end
  local _78_
  do
    local t_77_ = node
    if (nil ~= t_77_) then
      t_77_ = t_77_.url
    else
    end
    _78_ = t_77_
  end
  local _81_
  do
    local t_80_ = node
    if (nil ~= t_80_) then
      t_80_ = t_80_.isDraft
    else
    end
    _81_ = t_80_
  end
  local _83_
  if (review_decision == "APPROVED") then
    _83_ = "approved"
  elseif (review_decision == "CHANGES_REQUESTED") then
    _83_ = "rejected"
  else
    local _ = review_decision
    _83_ = "pending"
  end
  local _88_
  if (ci_state == "SUCCESS") then
    _88_ = "success"
  elseif (ci_state == "FAILURE") then
    _88_ = "failure"
  elseif (ci_state == "ERROR") then
    _88_ = "failure"
  elseif (ci_state == "PENDING") then
    _88_ = "running"
  elseif (ci_state == "EXPECTED") then
    _88_ = "running"
  else
    local _ = ci_state
    _88_ = "none"
  end
  local _97_
  do
    local t_96_ = node
    if (nil ~= t_96_) then
      t_96_ = t_96_.author
    else
    end
    if (nil ~= t_96_) then
      t_96_ = t_96_.login
    else
    end
    _97_ = t_96_
  end
  return {title = _75_, url = _78_, ["draft?"] = _81_, source = "github", ["review-status"] = _83_, ["ci-status"] = _88_, ["has-conflicts?"] = (mergeable == "CONFLICTING"), ["review-requested?"] = review_requested_3f(node), author = _97_, ["assignee?"] = assignee_3f(node)}
end
local function split_github_pull_requests(pull_requests)
  local review_3f
  local function _100_(_241)
    local t_101_ = _241
    if (nil ~= t_101_) then
      t_101_ = t_101_["review-requested?"]
    else
    end
    return t_101_
  end
  review_3f = _100_
  local user_3f
  local function _103_(_241)
    local _105_
    do
      local t_104_ = _241
      if (nil ~= t_104_) then
        t_104_ = t_104_.author
      else
      end
      _105_ = t_104_
    end
    local or_107_ = (_105_ == obj.username)
    if not or_107_ then
      local _109_
      do
        local t_108_ = _241
        if (nil ~= t_108_) then
          t_108_ = t_108_["assignee?"]
        else
        end
        _109_ = t_108_
      end
      or_107_ = (_109_ and not review_3f(_241))
    end
    return or_107_
  end
  user_3f = _103_
  local user = {}
  local reviews = {}
  local involved = {}
  for _, pull_request in ipairs(pull_requests) do
    if user_3f(pull_request) then
      table.insert(user, pull_request)
    elseif review_3f(pull_request) then
      table.insert(reviews, pull_request)
    else
      table.insert(involved, pull_request)
    end
  end
  return user, reviews, involved
end
local function github_callback(_, body, _0)
  local pull_requests
  local _112_
  if (nil ~= body) then
    local tmp_3_ = hs.json.decode(body)
    if (nil ~= tmp_3_) then
      local tmp_3_0
      do
        local t_115_ = tmp_3_
        if (nil ~= t_115_) then
          t_115_ = t_115_.data
        else
        end
        if (nil ~= t_115_) then
          t_115_ = t_115_.search
        else
        end
        if (nil ~= t_115_) then
          t_115_ = t_115_.nodes
        else
        end
        tmp_3_0 = t_115_
      end
      if (nil ~= tmp_3_0) then
        _112_ = hs.fnutils.imap(tmp_3_0, normalize_github_pr)
      else
        _112_ = nil
      end
    else
      _112_ = nil
    end
  else
    _112_ = nil
  end
  pull_requests = (_112_ or {})
  if (#pull_requests == 0) then
    obj.logger.i(body)
    local _122_
    if (nil ~= body) then
      local tmp_3_ = hs.json.decode(body)
      if (nil ~= tmp_3_) then
        local t_124_ = tmp_3_
        if (nil ~= t_124_) then
          t_124_ = t_124_.errors
        else
        end
        _122_ = t_124_
      else
        _122_ = nil
      end
    else
      _122_ = nil
    end
    if _122_ then
      return show_error("GraphQL query returned errors")
    else
      return nil
    end
  else
    local user, reviews, involved = split_github_pull_requests(pull_requests)
    state["github-user-prs"] = user
    state["github-review-prs"] = reviews
    state["github-involved-prs"] = involved
    return update_menu()
  end
end
local function github_update()
  local headers = {["Content-Type"] = "application/json", Authorization = ("bearer " .. state.token)}
  local url = "https://api.github.com/graphql"
  local data = ("{\"query\": \"query ActivePullRequests($query: String!) { search(query: $query, type: ISSUE, first: 100) { nodes { ... on PullRequest { author { login } url title isDraft mergeable reviewDecision reviewRequests(first: 100) { nodes { requestedReviewer { ... on User { login } } } } assignees(first: 100) { nodes { login } } commits(last: 1) { nodes { commit { statusCheckRollup { state } } } } } } } }\", \"variables\": { \"query\": \"sort:updated-desc type:pr state:open involves:" .. obj.username .. "\" } }")
  return hs.http.asyncPost(url, data, headers, github_callback)
end
local function get_pull_request_url(pr)
  local _131_
  do
    local t_130_ = pr
    if (nil ~= t_130_) then
      t_130_ = t_130_.repository
    else
    end
    _131_ = t_130_
  end
  local _134_
  do
    local t_133_ = pr
    if (nil ~= t_133_) then
      t_133_ = t_133_.id
    else
    end
    _134_ = t_133_
  end
  return (obj.organizationUrl .. obj.project .. "/_git/" .. _131_ .. "/pullrequest/" .. _134_)
end
local function azure_get_review_status(pr)
  local votes
  local _137_
  do
    local t_136_ = pr
    if (nil ~= t_136_) then
      t_136_ = t_136_.reviewerVotes
    else
    end
    _137_ = t_136_
  end
  votes = (_137_ or {})
  local has_approval = false
  local has_rejection = false
  for _, vote in ipairs(votes) do
    if ((vote == -10) or (vote == -5)) then
      has_rejection = true
    else
    end
    if ((vote == 10) or (vote == 5)) then
      has_approval = true
    else
    end
  end
  if has_rejection then
    return "rejected"
  elseif has_approval then
    return "approved"
  else
    return "pending"
  end
end
local function normalize_azure_pr(pr)
  local _143_
  do
    local t_142_ = pr
    if (nil ~= t_142_) then
      t_142_ = t_142_.title
    else
    end
    _143_ = t_142_
  end
  local _146_
  do
    local t_145_ = pr
    if (nil ~= t_145_) then
      t_145_ = t_145_.isDraft
    else
    end
    _146_ = t_145_
  end
  local _149_
  do
    local t_148_ = pr
    if (nil ~= t_148_) then
      t_148_ = t_148_.mergeStatus
    else
    end
    _149_ = t_148_
  end
  local _152_
  do
    local t_151_ = pr
    if (nil ~= t_151_) then
      t_151_ = t_151_.id
    else
    end
    _152_ = t_151_
  end
  local _155_
  do
    local t_154_ = pr
    if (nil ~= t_154_) then
      t_154_ = t_154_.mergeStatus
    else
    end
    _155_ = t_154_
  end
  return {title = _143_, url = get_pull_request_url(pr), ["draft?"] = _146_, source = "azure", ["review-status"] = azure_get_review_status(pr), ["ci-status"] = "none", ["has-conflicts?"] = (_149_ == "conflicts"), id = _152_, mergeStatus = _155_}
end
local function filter_ignored_repos(prs)
  if (#obj.ignoredRepos == 0) then
    return prs
  else
    local ignored
    do
      local tbl_21_ = {}
      for _, repo in ipairs(obj.ignoredRepos) do
        local k_22_, v_23_ = repo, true
        if ((k_22_ ~= nil) and (v_23_ ~= nil)) then
          tbl_21_[k_22_] = v_23_
        else
        end
      end
      ignored = tbl_21_
    end
    local tbl_26_ = {}
    local i_27_ = 0
    for _, pr in ipairs(prs) do
      local val_28_
      local _159_
      do
        local t_158_ = pr
        if (nil ~= t_158_) then
          t_158_ = t_158_.repository
        else
        end
        _159_ = t_158_
      end
      if not ignored[_159_] then
        val_28_ = pr
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    return tbl_26_
  end
end
local function parse_pr_response(json_output)
  local prs = (hs.json.decode(json_output) or {})
  return prs
end
local function parse_ci_status(policies)
  local build_policies
  do
    local tbl_26_ = {}
    local i_27_ = 0
    for _, p in ipairs(policies) do
      local val_28_
      local _165_
      do
        local t_164_ = p
        if (nil ~= t_164_) then
          t_164_ = t_164_.configuration
        else
        end
        if (nil ~= t_164_) then
          t_164_ = t_164_.type
        else
        end
        if (nil ~= t_164_) then
          t_164_ = t_164_.displayName
        else
        end
        _165_ = t_164_
      end
      if (_165_ == "Build") then
        val_28_ = p
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    build_policies = tbl_26_
  end
  if (#build_policies == 0) then
    return "none"
  else
    local has_rejected = false
    local all_approved = true
    for _, p in ipairs(build_policies) do
      local status
      do
        local t_171_ = p
        if (nil ~= t_171_) then
          t_171_ = t_171_.status
        else
        end
        status = t_171_
      end
      if (status == "rejected") then
        has_rejected = true
      else
      end
      if (status ~= "approved") then
        all_approved = false
      else
      end
    end
    if has_rejected then
      return "failure"
    elseif all_approved then
      return "success"
    else
      return "running"
    end
  end
end
local function make_policy_callback(pr_id)
  local function _177_(exit_code, std_out, _std_err)
    if (exit_code == 0) then
      local policies = (hs.json.decode(std_out) or {})
      local ci_status = parse_ci_status(policies)
      for _, pr in ipairs(state["azure-creator-prs"]) do
        local _179_
        do
          local t_178_ = pr
          if (nil ~= t_178_) then
            t_178_ = t_178_.id
          else
          end
          _179_ = t_178_
        end
        if (_179_ == pr_id) then
          pr["ci-status"] = ci_status
        else
        end
      end
      for _, pr in ipairs(state["azure-reviewer-prs"]) do
        local _183_
        do
          local t_182_ = pr
          if (nil ~= t_182_) then
            t_182_ = t_182_.id
          else
          end
          _183_ = t_182_
        end
        if (_183_ == pr_id) then
          pr["ci-status"] = ci_status
        else
        end
      end
      return update_menu()
    else
      return nil
    end
  end
  return _177_
end
local function fetch_policy_status(pr_id)
  local args = {"repos", "pr", "policy", "list", "--id", tostring(pr_id), "--organization", obj.organizationUrl}
  local callback = make_policy_callback(pr_id)
  local task = hs.task.new(obj.azPath, callback, args)
  return task:start()
end
local function fetch_policy_status_for_prs(prs)
  for _, pr in ipairs(prs) do
    local pr_id
    do
      local t_187_ = pr
      if (nil ~= t_187_) then
        t_187_ = t_187_.id
      else
      end
      pr_id = t_187_
    end
    if pr_id then
      fetch_policy_status(pr_id)
    else
    end
  end
  return nil
end
local function azure_creator_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local raw_prs = filter_ignored_repos(parse_pr_response(std_out))
    local prs = hs.fnutils.imap(raw_prs, normalize_azure_pr)
    state["azure-creator-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch Azure creator PRs: " .. std_err))
  end
end
local function azure_reviewer_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local raw_prs = filter_ignored_repos(parse_pr_response(std_out))
    local prs = hs.fnutils.imap(raw_prs, normalize_azure_pr)
    state["azure-reviewer-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch Azure reviewer PRs: " .. std_err))
  end
end
local function fetch_creator_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus," .. "reviewerVotes: reviewers[].vote" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--creator", obj.userEmail}
  local task = hs.task.new(obj.azPath, azure_creator_callback, args)
  return task:start()
end
local function fetch_reviewer_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus," .. "reviewerVotes: reviewers[].vote" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--reviewer", obj.userEmail}
  local task = hs.task.new(obj.azPath, azure_reviewer_callback, args)
  return task:start()
end
local function azure_update()
  fetch_creator_prs()
  return fetch_reviewer_prs()
end
local function _192_()
  local user_prs
  do
    local combined = {}
    for _, pr in ipairs(state["github-user-prs"]) do
      table.insert(combined, pr)
    end
    for _, pr in ipairs(state["azure-creator-prs"]) do
      table.insert(combined, pr)
    end
    user_prs = combined
  end
  local review_prs
  do
    local combined = {}
    for _, pr in ipairs(state["github-review-prs"]) do
      table.insert(combined, pr)
    end
    for _, pr in ipairs(state["azure-reviewer-prs"]) do
      table.insert(combined, pr)
    end
    review_prs = combined
  end
  local involved_prs = state["github-involved-prs"]
  local total_count = (#user_prs + #review_prs + #involved_prs)
  local menu_title = get_menu_title(total_count)
  local menu_table = get_menu_table({user_prs, review_prs, involved_prs})
  obj.menuItem:setTitle(menu_title)
  return obj.menuItem:setMenu(menu_table)
end
update_menu = _192_
local function update()
  state["last-update"] = os.time()
  github_update()
  return azure_update()
end
obj.init = function(self)
  self.logger = hs.logger.new("GHADOPullRequest")
  self.menuItem = hs.menubar.new()
  do
    local icon = make_icon()
    self.menuItem:setIcon(icon, true)
  end
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  state.token = fetch_token(self.skatePath, self.skateItem)
  self.menuItem:setTitle("...")
  self.timer:start()
  self.timer:setNextTrigger(0)
  return self
end
obj.stop = function(self)
  self.timer:stop()
  self.menuItem:setTitle("...")
  self.menuItem:setMenu(nil)
  state["github-user-prs"] = {}
  state["github-review-prs"] = {}
  state["github-involved-prs"] = {}
  state["azure-creator-prs"] = {}
  state["azure-reviewer-prs"] = {}
  state.token = nil
  state["last-update"] = nil
  return self
end
return obj
