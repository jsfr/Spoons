local obj = {}
obj.__index = obj
obj.name = "GHADOPullRequest"
obj.version = "1.1"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.username = nil
obj.skateItem = nil
obj.skatePath = "/opt/homebrew/bin/skate"
obj.organizationUrl = nil
obj.project = nil
obj.userEmail = nil
obj.azPath = "/opt/homebrew/bin/az"
obj.ignoredRepos = {}
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local function fetch_token(skatePath, skateItem)
  local command = (skatePath .. " get " .. skateItem)
  local handle = io.popen(command)
  local function close_handlers_13_(ok_14_, ...)
    handle:close()
    if ok_14_ then
      return ...
    else
      return error(..., 0)
    end
  end
  local function _2_()
    local output = handle:read("*a")
    return output:gsub("^%s*(.-)%s*$", "%1")
  end
  local _4_
  do
    local t_3_ = _G
    if (nil ~= t_3_) then
      t_3_ = t_3_.package
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.loaded
    else
    end
    if (nil ~= t_3_) then
      t_3_ = t_3_.fennel
    else
    end
    _4_ = t_3_
  end
  local or_8_ = _4_ or _G.debug
  if not or_8_ then
    local function _9_()
      return ""
    end
    or_8_ = {traceback = _9_}
  end
  return close_handlers_13_(_G.xpcall(_2_, or_8_.traceback))
end
local state = {["github-user-prs"] = {}, ["github-review-prs"] = {}, ["github-involved-prs"] = {}, ["azure-creator-prs"] = {}, ["azure-reviewer-prs"] = {}, ["azure-ci-status"] = {}, token = nil, ["last-update"] = nil}
local function make_icon()
  local ascii = "ASCII:\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . . . . . . . . . . . . . .\n. . 1 . . . 1 . . . 8 . . . 8 . .\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . 2 . . . . . . . 7 . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 4 . . 5 . . . 6 . . . . .\n. . . . 2 . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . 3 . . . 3 . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . ."
  local context = {{strokeColor = {red = 1, green = 1, blue = 1, alpha = 1}, fillColor = {alpha = 0}, lineWidth = 1.2, shouldClose = false}}
  return hs.image.imageFromASCII(ascii, context)
end
local function get_menu_title(total_count)
  return hs.styledtext.new(tostring(total_count))
end
local function get_error_title()
  local error_style = {color = {red = 1.0, green = 0, blue = 0, alpha = 1.0}}
  return hs.styledtext.new("error", error_style)
end
local function show_error(error_message)
  obj.logger.e(error_message)
  obj.menuItem:setTitle(get_error_title())
  return obj.menuItem:setMenu(nil)
end
local function get_last_update_text()
  if state["last-update"] then
    return ("Last update: " .. os.date("%Y-%m-%d %H:%M:%S", state["last-update"]))
  else
    return "Last update: never"
  end
end
local function get_title(pull_request)
  local title
  do
    local t_11_ = pull_request
    if (nil ~= t_11_) then
      t_11_ = t_11_.title
    else
    end
    title = t_11_
  end
  local source_prefix
  local _14_
  do
    local t_13_ = pull_request
    if (nil ~= t_13_) then
      t_13_ = t_13_.source
    else
    end
    _14_ = t_13_
  end
  if (_14_ == "github") then
    source_prefix = "[GH] "
  else
    source_prefix = "[ADO] "
  end
  local emoji
  do
    local t_17_ = pull_request
    if (nil ~= t_17_) then
      t_17_ = t_17_["status-emoji"]
    else
    end
    emoji = t_17_
  end
  local draft_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local text
  local _20_
  do
    local t_19_ = pull_request
    if (nil ~= t_19_) then
      t_19_ = t_19_["draft?"]
    else
    end
    _20_ = t_19_
  end
  if _20_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style
  local _24_
  do
    local t_23_ = pull_request
    if (nil ~= t_23_) then
      t_23_ = t_23_["draft?"]
    else
    end
    _24_ = t_23_
  end
  if _24_ then
    style = draft_style
  else
    local t_26_ = pull_request
    if (nil ~= t_26_) then
      t_26_ = t_26_.style
    else
    end
    style = t_26_
  end
  return hs.styledtext.new((source_prefix .. emoji .. text), style)
end
local function get_menu_line(pull_request)
  local function _29_()
    local function _31_()
      local t_30_ = pull_request
      if (nil ~= t_30_) then
        t_30_ = t_30_.url
      else
      end
      return t_30_
    end
    return hs.urlevent.openURL(_31_())
  end
  return {title = get_title(pull_request), fn = _29_}
end
local update_menu = nil
local function get_menu_table(list_of_pull_requests)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  local reload_line
  local function _33_()
    return hs.reload()
  end
  reload_line = {title = "\240\159\148\132 Reload Hammerspoon", fn = _33_}
  local last_update_line = {title = hs.styledtext.new(get_last_update_text(), empty_style), disabled = true}
  for i, pull_requests in ipairs(list_of_pull_requests) do
    if (i > 1) then
      table.insert(menu_table, separator)
    else
    end
    if (#pull_requests > 0) then
      for _, pull_request in ipairs(pull_requests) do
        table.insert(menu_table, get_menu_line(pull_request))
      end
    else
      table.insert(menu_table, empty_block)
    end
  end
  table.insert(menu_table, separator)
  table.insert(menu_table, reload_line)
  table.insert(menu_table, last_update_line)
  return menu_table
end
local function github_get_status_emoji(pull_request)
  local _37_
  do
    local t_36_ = pull_request
    if (nil ~= t_36_) then
      t_36_ = t_36_.mergeable
    else
    end
    _37_ = t_36_
  end
  if (_37_ == "CONFLICTING") then
    return "\226\154\148\239\184\143 "
  else
    local case_39_
    do
      local t_40_ = pull_request
      if (nil ~= t_40_) then
        t_40_ = t_40_["review-decision"]
      else
      end
      case_39_ = t_40_
    end
    if (case_39_ == "APPROVED") then
      return "\226\156\133 "
    elseif (case_39_ == "CHANGES_REQUESTED") then
      return "\226\157\140 "
    else
      local _ = case_39_
      return "\226\143\179 "
    end
  end
end
local function github_get_ci_status_style(ci_status)
  if (ci_status == "SUCCESS") then
    return {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
  elseif (ci_status == "FAILURE") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  elseif (ci_status == "ERROR") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  else
    local _ = ci_status
    return {}
  end
end
local function github_get_style(node)
  local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
  local ci_status
  do
    local t_45_ = node
    if (nil ~= t_45_) then
      t_45_ = t_45_.commits
    else
    end
    if (nil ~= t_45_) then
      t_45_ = t_45_.nodes
    else
    end
    if (nil ~= t_45_) then
      t_45_ = t_45_[1]
    else
    end
    if (nil ~= t_45_) then
      t_45_ = t_45_.commit
    else
    end
    if (nil ~= t_45_) then
      t_45_ = t_45_.statusCheckRollup
    else
    end
    if (nil ~= t_45_) then
      t_45_ = t_45_.state
    else
    end
    ci_status = t_45_
  end
  local _53_
  do
    local t_52_ = node
    if (nil ~= t_52_) then
      t_52_ = t_52_.mergeable
    else
    end
    _53_ = t_52_
  end
  if (_53_ == "CONFLICTING") then
    return conflict_style
  else
    return github_get_ci_status_style(ci_status)
  end
end
local function review_requested_3f(node)
  local _57_
  do
    local t_56_ = node
    if (nil ~= t_56_) then
      t_56_ = t_56_.reviewRequests
    else
    end
    if (nil ~= t_56_) then
      t_56_ = t_56_.nodes
    else
    end
    _57_ = t_56_
  end
  local function _60_(_241)
    local _62_
    do
      local t_61_ = _241
      if (nil ~= t_61_) then
        t_61_ = t_61_.requestedReviewer
      else
      end
      if (nil ~= t_61_) then
        t_61_ = t_61_.login
      else
      end
      _62_ = t_61_
    end
    return (_62_ == obj.username)
  end
  return hs.fnutils.some(_57_, _60_)
end
local function assignee_3f(node)
  local _66_
  do
    local t_65_ = node
    if (nil ~= t_65_) then
      t_65_ = t_65_.assignees
    else
    end
    if (nil ~= t_65_) then
      t_65_ = t_65_.nodes
    else
    end
    _66_ = t_65_
  end
  local function _69_(_241)
    local _71_
    do
      local t_70_ = _241
      if (nil ~= t_70_) then
        t_70_ = t_70_.login
      else
      end
      _71_ = t_70_
    end
    return (_71_ == obj.username)
  end
  return hs.fnutils.some(_66_, _69_)
end
local function normalize_github_pr(node)
  local _74_
  do
    local t_73_ = node
    if (nil ~= t_73_) then
      t_73_ = t_73_.title
    else
    end
    _74_ = t_73_
  end
  local _77_
  do
    local t_76_ = node
    if (nil ~= t_76_) then
      t_76_ = t_76_.url
    else
    end
    _77_ = t_76_
  end
  local _80_
  do
    local t_79_ = node
    if (nil ~= t_79_) then
      t_79_ = t_79_.isDraft
    else
    end
    _80_ = t_79_
  end
  local _83_
  do
    local t_82_ = node
    if (nil ~= t_82_) then
      t_82_ = t_82_.reviewDecision
    else
    end
    _83_ = t_82_
  end
  local _86_
  do
    local t_85_ = node
    if (nil ~= t_85_) then
      t_85_ = t_85_.mergeable
    else
    end
    _86_ = t_85_
  end
  local _89_
  do
    local t_88_ = node
    if (nil ~= t_88_) then
      t_88_ = t_88_.commits
    else
    end
    if (nil ~= t_88_) then
      t_88_ = t_88_.nodes
    else
    end
    if (nil ~= t_88_) then
      t_88_ = t_88_[1]
    else
    end
    if (nil ~= t_88_) then
      t_88_ = t_88_.commit
    else
    end
    if (nil ~= t_88_) then
      t_88_ = t_88_.statusCheckRollup
    else
    end
    if (nil ~= t_88_) then
      t_88_ = t_88_.state
    else
    end
    _89_ = t_88_
  end
  local _97_
  do
    local t_96_ = node
    if (nil ~= t_96_) then
      t_96_ = t_96_.author
    else
    end
    if (nil ~= t_96_) then
      t_96_ = t_96_.login
    else
    end
    _97_ = t_96_
  end
  return {title = _74_, url = _77_, ["draft?"] = _80_, source = "github", ["status-emoji"] = github_get_status_emoji(node), style = github_get_style(node), ["review-requested?"] = review_requested_3f(node), ["review-decision"] = _83_, mergeable = _86_, ["ci-status"] = _89_, author = _97_, ["assignee?"] = assignee_3f(node)}
end
local function split_github_pull_requests(pull_requests)
  local review_3f
  local function _100_(_241)
    local t_101_ = _241
    if (nil ~= t_101_) then
      t_101_ = t_101_["review-requested?"]
    else
    end
    return t_101_
  end
  review_3f = _100_
  local user_3f
  local function _103_(_241)
    local _105_
    do
      local t_104_ = _241
      if (nil ~= t_104_) then
        t_104_ = t_104_.author
      else
      end
      _105_ = t_104_
    end
    local or_107_ = (_105_ == obj.username)
    if not or_107_ then
      local _109_
      do
        local t_108_ = _241
        if (nil ~= t_108_) then
          t_108_ = t_108_["assignee?"]
        else
        end
        _109_ = t_108_
      end
      or_107_ = (_109_ and not review_3f(_241))
    end
    return or_107_
  end
  user_3f = _103_
  local user = {}
  local reviews = {}
  local involved = {}
  for _, pull_request in ipairs(pull_requests) do
    if user_3f(pull_request) then
      table.insert(user, pull_request)
    elseif review_3f(pull_request) then
      table.insert(reviews, pull_request)
    else
      table.insert(involved, pull_request)
    end
  end
  return user, reviews, involved
end
local function github_callback(_, body, _0)
  local pull_requests
  local _112_
  if (nil ~= body) then
    local tmp_3_ = hs.json.decode(body)
    if (nil ~= tmp_3_) then
      local tmp_3_0
      do
        local t_115_ = tmp_3_
        if (nil ~= t_115_) then
          t_115_ = t_115_.data
        else
        end
        if (nil ~= t_115_) then
          t_115_ = t_115_.search
        else
        end
        if (nil ~= t_115_) then
          t_115_ = t_115_.nodes
        else
        end
        tmp_3_0 = t_115_
      end
      if (nil ~= tmp_3_0) then
        _112_ = hs.fnutils.imap(tmp_3_0, normalize_github_pr)
      else
        _112_ = nil
      end
    else
      _112_ = nil
    end
  else
    _112_ = nil
  end
  pull_requests = (_112_ or {})
  if (#pull_requests == 0) then
    obj.logger.i(body)
    local _122_
    if (nil ~= body) then
      local tmp_3_ = hs.json.decode(body)
      if (nil ~= tmp_3_) then
        local t_124_ = tmp_3_
        if (nil ~= t_124_) then
          t_124_ = t_124_.errors
        else
        end
        _122_ = t_124_
      else
        _122_ = nil
      end
    else
      _122_ = nil
    end
    if _122_ then
      return show_error("GraphQL query returned errors")
    else
      return nil
    end
  else
    local user, reviews, involved = split_github_pull_requests(pull_requests)
    state["github-user-prs"] = user
    state["github-review-prs"] = reviews
    state["github-involved-prs"] = involved
    return update_menu()
  end
end
local function github_update()
  local headers = {["Content-Type"] = "application/json", Authorization = ("bearer " .. state.token)}
  local url = "https://api.github.com/graphql"
  local data = ("{\"query\": \"query ActivePullRequests($query: String!) { search(query: $query, type: ISSUE, first: 100) { nodes { ... on PullRequest { author { login } url title isDraft mergeable reviewDecision reviewRequests(first: 100) { nodes { requestedReviewer { ... on User { login } } } } assignees(first: 100) { nodes { login } } commits(last: 1) { nodes { commit { statusCheckRollup { state } } } } } } } }\", \"variables\": { \"query\": \"sort:updated-desc type:pr state:open involves:" .. obj.username .. "\" } }")
  return hs.http.asyncPost(url, data, headers, github_callback)
end
local function azure_get_status_emoji(pull_request)
  local case_130_
  do
    local t_131_ = pull_request
    if (nil ~= t_131_) then
      t_131_ = t_131_.mergeStatus
    else
    end
    case_130_ = t_131_
  end
  if (case_130_ == "succeeded") then
    return "\226\156\133 "
  elseif (case_130_ == "rejectedByPolicy") then
    return "\226\157\140 "
  elseif (case_130_ == "conflicts") then
    return "\226\154\148\239\184\143 "
  else
    local _ = case_130_
    return "\226\143\179 "
  end
end
local function azure_get_ci_status_style(pull_request)
  local pr_id
  do
    local t_134_ = pull_request
    if (nil ~= t_134_) then
      t_134_ = t_134_.id
    else
    end
    pr_id = t_134_
  end
  local ci_status = state["azure-ci-status"][pr_id]
  if (ci_status == "passed") then
    return {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
  elseif (ci_status == "failed") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  else
    local _ = ci_status
    return {}
  end
end
local function azure_get_style(pull_request)
  local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
  local _138_
  do
    local t_137_ = pull_request
    if (nil ~= t_137_) then
      t_137_ = t_137_.mergeStatus
    else
    end
    _138_ = t_137_
  end
  if (_138_ == "conflicts") then
    return conflict_style
  else
    return azure_get_ci_status_style(pull_request)
  end
end
local function get_pull_request_url(pr)
  local _142_
  do
    local t_141_ = pr
    if (nil ~= t_141_) then
      t_141_ = t_141_.repository
    else
    end
    _142_ = t_141_
  end
  local _145_
  do
    local t_144_ = pr
    if (nil ~= t_144_) then
      t_144_ = t_144_.id
    else
    end
    _145_ = t_144_
  end
  return (obj.organizationUrl .. obj.project .. "/_git/" .. _142_ .. "/pullrequest/" .. _145_)
end
local function normalize_azure_pr(pr)
  local _148_
  do
    local t_147_ = pr
    if (nil ~= t_147_) then
      t_147_ = t_147_.title
    else
    end
    _148_ = t_147_
  end
  local _151_
  do
    local t_150_ = pr
    if (nil ~= t_150_) then
      t_150_ = t_150_.isDraft
    else
    end
    _151_ = t_150_
  end
  local _154_
  do
    local t_153_ = pr
    if (nil ~= t_153_) then
      t_153_ = t_153_.id
    else
    end
    _154_ = t_153_
  end
  local _157_
  do
    local t_156_ = pr
    if (nil ~= t_156_) then
      t_156_ = t_156_.mergeStatus
    else
    end
    _157_ = t_156_
  end
  return {title = _148_, url = get_pull_request_url(pr), ["draft?"] = _151_, source = "azure", ["status-emoji"] = azure_get_status_emoji(pr), style = azure_get_style(pr), id = _154_, mergeStatus = _157_}
end
local function filter_ignored_repos(prs)
  if (#obj.ignoredRepos == 0) then
    return prs
  else
    local ignored
    do
      local tbl_21_ = {}
      for _, repo in ipairs(obj.ignoredRepos) do
        local k_22_, v_23_ = repo, true
        if ((k_22_ ~= nil) and (v_23_ ~= nil)) then
          tbl_21_[k_22_] = v_23_
        else
        end
      end
      ignored = tbl_21_
    end
    local tbl_26_ = {}
    local i_27_ = 0
    for _, pr in ipairs(prs) do
      local val_28_
      local _161_
      do
        local t_160_ = pr
        if (nil ~= t_160_) then
          t_160_ = t_160_.repository
        else
        end
        _161_ = t_160_
      end
      if not ignored[_161_] then
        val_28_ = pr
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    return tbl_26_
  end
end
local function parse_pr_response(json_output)
  local prs = (hs.json.decode(json_output) or {})
  return prs
end
local function parse_ci_status(policies)
  local build_policies
  do
    local tbl_26_ = {}
    local i_27_ = 0
    for _, p in ipairs(policies) do
      local val_28_
      local _167_
      do
        local t_166_ = p
        if (nil ~= t_166_) then
          t_166_ = t_166_.configuration
        else
        end
        if (nil ~= t_166_) then
          t_166_ = t_166_.type
        else
        end
        if (nil ~= t_166_) then
          t_166_ = t_166_.displayName
        else
        end
        _167_ = t_166_
      end
      if (_167_ == "Build") then
        val_28_ = p
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    build_policies = tbl_26_
  end
  if (#build_policies == 0) then
    return nil
  else
    local has_rejected = false
    local all_approved = true
    for _, p in ipairs(build_policies) do
      local status
      do
        local t_173_ = p
        if (nil ~= t_173_) then
          t_173_ = t_173_.status
        else
        end
        status = t_173_
      end
      if (status == "rejected") then
        has_rejected = true
      else
      end
      if (status ~= "approved") then
        all_approved = false
      else
      end
    end
    if has_rejected then
      return "failed"
    elseif all_approved then
      return "passed"
    else
      return nil
    end
  end
end
local function make_policy_callback(pr_id)
  local function _179_(exit_code, std_out, _std_err)
    if (exit_code == 0) then
      local policies = (hs.json.decode(std_out) or {})
      local ci_status = parse_ci_status(policies)
      state["azure-ci-status"][pr_id] = ci_status
      do
        local tbl_26_ = {}
        local i_27_ = 0
        for _, pr in ipairs(state["azure-creator-prs"]) do
          local val_28_
          local _181_
          do
            local t_180_ = pr
            if (nil ~= t_180_) then
              t_180_ = t_180_.id
            else
            end
            _181_ = t_180_
          end
          if (_181_ == pr_id) then
            local _183_
            do
              local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
              local _185_
              do
                local t_184_ = pr
                if (nil ~= t_184_) then
                  t_184_ = t_184_.mergeStatus
                else
                end
                _185_ = t_184_
              end
              if (_185_ == "conflicts") then
                _183_ = conflict_style
              else
                if (ci_status == "passed") then
                  _183_ = {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
                elseif (ci_status == "failed") then
                  _183_ = {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
                else
                  local _0 = ci_status
                  _183_ = {}
                end
              end
            end
            pr["style"] = _183_
            val_28_ = pr
          else
            val_28_ = pr
          end
          if (nil ~= val_28_) then
            i_27_ = (i_27_ + 1)
            tbl_26_[i_27_] = val_28_
          else
          end
        end
        state["azure-creator-prs"] = tbl_26_
      end
      do
        local tbl_26_ = {}
        local i_27_ = 0
        for _, pr in ipairs(state["azure-reviewer-prs"]) do
          local val_28_
          local _195_
          do
            local t_194_ = pr
            if (nil ~= t_194_) then
              t_194_ = t_194_.id
            else
            end
            _195_ = t_194_
          end
          if (_195_ == pr_id) then
            local _197_
            do
              local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
              local _199_
              do
                local t_198_ = pr
                if (nil ~= t_198_) then
                  t_198_ = t_198_.mergeStatus
                else
                end
                _199_ = t_198_
              end
              if (_199_ == "conflicts") then
                _197_ = conflict_style
              else
                if (ci_status == "passed") then
                  _197_ = {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
                elseif (ci_status == "failed") then
                  _197_ = {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
                else
                  local _0 = ci_status
                  _197_ = {}
                end
              end
            end
            pr["style"] = _197_
            val_28_ = pr
          else
            val_28_ = pr
          end
          if (nil ~= val_28_) then
            i_27_ = (i_27_ + 1)
            tbl_26_[i_27_] = val_28_
          else
          end
        end
        state["azure-reviewer-prs"] = tbl_26_
      end
      return update_menu()
    else
      return nil
    end
  end
  return _179_
end
local function fetch_policy_status(pr_id)
  local args = {"repos", "pr", "policy", "list", "--id", tostring(pr_id), "--organization", obj.organizationUrl}
  local callback = make_policy_callback(pr_id)
  local task = hs.task.new(obj.azPath, callback, args)
  return task:start()
end
local function fetch_policy_status_for_prs(prs)
  for _, pr in ipairs(prs) do
    local pr_id
    do
      local t_209_ = pr
      if (nil ~= t_209_) then
        t_209_ = t_209_.id
      else
      end
      pr_id = t_209_
    end
    if pr_id then
      fetch_policy_status(pr_id)
    else
    end
  end
  return nil
end
local function azure_creator_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local raw_prs = filter_ignored_repos(parse_pr_response(std_out))
    local prs = hs.fnutils.imap(raw_prs, normalize_azure_pr)
    state["azure-creator-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch Azure creator PRs: " .. std_err))
  end
end
local function azure_reviewer_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local raw_prs = filter_ignored_repos(parse_pr_response(std_out))
    local prs = hs.fnutils.imap(raw_prs, normalize_azure_pr)
    state["azure-reviewer-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch Azure reviewer PRs: " .. std_err))
  end
end
local function fetch_creator_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--creator", obj.userEmail}
  local task = hs.task.new(obj.azPath, azure_creator_callback, args)
  return task:start()
end
local function fetch_reviewer_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--reviewer", obj.userEmail}
  local task = hs.task.new(obj.azPath, azure_reviewer_callback, args)
  return task:start()
end
local function azure_update()
  fetch_creator_prs()
  return fetch_reviewer_prs()
end
local function _214_()
  local user_prs
  do
    local combined = {}
    for _, pr in ipairs(state["github-user-prs"]) do
      table.insert(combined, pr)
    end
    for _, pr in ipairs(state["azure-creator-prs"]) do
      table.insert(combined, pr)
    end
    user_prs = combined
  end
  local review_prs
  do
    local combined = {}
    for _, pr in ipairs(state["github-review-prs"]) do
      table.insert(combined, pr)
    end
    for _, pr in ipairs(state["azure-reviewer-prs"]) do
      table.insert(combined, pr)
    end
    review_prs = combined
  end
  local involved_prs = state["github-involved-prs"]
  local total_count = (#user_prs + #review_prs + #involved_prs)
  local menu_title = get_menu_title(total_count)
  local menu_table = get_menu_table({user_prs, review_prs, involved_prs})
  obj.menuItem:setTitle(menu_title)
  return obj.menuItem:setMenu(menu_table)
end
update_menu = _214_
local function update()
  state["last-update"] = os.time()
  github_update()
  return azure_update()
end
obj.init = function(self)
  self.logger = hs.logger.new("GHADOPullRequest")
  self.menuItem = hs.menubar.new()
  do
    local icon = make_icon()
    self.menuItem:setIcon(icon, true)
  end
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  state.token = fetch_token(self.skatePath, self.skateItem)
  self.menuItem:setTitle("...")
  self.timer:start()
  self.timer:setNextTrigger(0)
  return self
end
obj.stop = function(self)
  self.timer:stop()
  self.menuItem:setTitle("...")
  self.menuItem:setMenu(nil)
  state["github-user-prs"] = {}
  state["github-review-prs"] = {}
  state["github-involved-prs"] = {}
  state["azure-creator-prs"] = {}
  state["azure-reviewer-prs"] = {}
  state["azure-ci-status"] = {}
  state.token = nil
  state["last-update"] = nil
  return self
end
return obj
