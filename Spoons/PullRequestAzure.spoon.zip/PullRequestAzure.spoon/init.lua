local obj = {}
obj.__index = obj
obj.name = "PullRequestAzure"
obj.version = "1.1"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.organizationUrl = nil
obj.project = nil
obj.userEmail = nil
obj.azPath = "/opt/homebrew/bin/az"
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local state = {["creator-prs"] = {}, ["reviewer-prs"] = {}}
local function make_icon()
  local ascii = "ASCII:\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . . . . . . . . . . . . . .\n. . 1 . . . 1 . . . 8 . . . 8 . .\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . 2 . . . . . . . 7 . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 4 . . 5 . . . 6 . . . . .\n. . . . 2 . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . 3 . . . 3 . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . ."
  local context = {{strokeColor = {red = 1, green = 1, blue = 1, alpha = 1}, fillColor = {alpha = 0}, lineWidth = 1, shouldClose = false}}
  return hs.image.imageFromASCII(ascii, context)
end
local function get_pull_request_url(pr)
  local _2_
  do
    local t_1_ = pr
    if (nil ~= t_1_) then
      t_1_ = t_1_.repository
    else
    end
    _2_ = t_1_
  end
  local _5_
  do
    local t_4_ = pr
    if (nil ~= t_4_) then
      t_4_ = t_4_.id
    else
    end
    _5_ = t_4_
  end
  return (obj.organizationUrl .. obj.project .. "/_git/" .. _2_ .. "/pullrequest/" .. _5_)
end
local function get_ready_icon(pr)
  local case_7_
  do
    local t_8_ = pr
    if (nil ~= t_8_) then
      t_8_ = t_8_.mergeStatus
    else
    end
    case_7_ = t_8_
  end
  if (case_7_ == "succeeded") then
    return "on"
  elseif (case_7_ == "rejectedByPolicy") then
    return "mixed"
  else
    local _ = case_7_
    return "off"
  end
end
local function get_menu_title(total_count)
  return hs.styledtext.new(tostring(total_count))
end
local function get_title(pull_request)
  local title
  do
    local t_11_ = pull_request
    if (nil ~= t_11_) then
      t_11_ = t_11_.title
    else
    end
    title = t_11_
  end
  local draft_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local text
  local _14_
  do
    local t_13_ = pull_request
    if (nil ~= t_13_) then
      t_13_ = t_13_.isDraft
    else
    end
    _14_ = t_13_
  end
  if _14_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style
  local _18_
  do
    local t_17_ = pull_request
    if (nil ~= t_17_) then
      t_17_ = t_17_.isDraft
    else
    end
    _18_ = t_17_
  end
  if _18_ then
    style = draft_style
  else
    style = {}
  end
  return hs.styledtext.new(text, style)
end
local function get_menu_line(pull_request)
  local function _21_()
    return hs.urlevent.openURL(get_pull_request_url(pull_request))
  end
  return {title = get_title(pull_request), fn = _21_, state = get_ready_icon(pull_request)}
end
local function get_menu_table(creator_prs, reviewer_prs)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  if (#creator_prs > 0) then
    for _, pr in ipairs(creator_prs) do
      table.insert(menu_table, get_menu_line(pr))
    end
  else
    table.insert(menu_table, empty_block)
  end
  table.insert(menu_table, separator)
  if (#reviewer_prs > 0) then
    for _, pr in ipairs(reviewer_prs) do
      table.insert(menu_table, get_menu_line(pr))
    end
  else
    table.insert(menu_table, empty_block)
  end
  return menu_table
end
local function parse_pr_response(json_output)
  local prs = (hs.json.decode(json_output) or {})
  return prs
end
local function update_menu()
  local creator_prs = state["creator-prs"]
  local reviewer_prs = state["reviewer-prs"]
  local total_count = (#creator_prs + #reviewer_prs)
  local menu_title = get_menu_title(total_count)
  local menu_table = get_menu_table(creator_prs, reviewer_prs)
  obj.menuItem:setTitle(menu_title)
  return obj.menuItem:setMenu(menu_table)
end
local function creator_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    state["creator-prs"] = parse_pr_response(std_out)
    return update_menu()
  else
    return obj.logger.e(("Failed to fetch creator PRs: " .. std_err))
  end
end
local function reviewer_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    state["reviewer-prs"] = parse_pr_response(std_out)
    return update_menu()
  else
    return obj.logger.e(("Failed to fetch reviewer PRs: " .. std_err))
  end
end
local function fetch_creator_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--creator", obj.userEmail}
  local task = hs.task.new(obj.azPath, creator_callback, args)
  return task:start()
end
local function fetch_reviewer_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--reviewer", obj.userEmail}
  local task = hs.task.new(obj.azPath, reviewer_callback, args)
  return task:start()
end
local function update()
  fetch_creator_prs()
  return fetch_reviewer_prs()
end
obj.init = function(self)
  self.logger = hs.logger.new("PullRequestAzure")
  self.menuItem = hs.menubar.new()
  do
    local icon = make_icon()
    self.menuItem:setIcon(icon, true)
  end
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  self.menuItem:setTitle("...")
  self.timer:start()
  self.timer:setNextTrigger(0)
  return self
end
obj.stop = function(self)
  self.timer:stop()
  self.menuItem:setTitle("...")
  self.menuItem:setMenu(nil)
  return self
end
return obj
