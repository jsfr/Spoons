local obj = {}
obj.__index = obj
obj.name = "PullRequestAzure"
obj.version = "1.6"
obj.author = "Jens Fredskov <jensfredskov@gmail.com>"
obj.license = "MIT - https://opensource.org/licenses/MIT"
obj.organizationUrl = nil
obj.project = nil
obj.userEmail = nil
obj.azPath = "/opt/homebrew/bin/az"
obj.menuItem = nil
obj.timer = nil
obj.logger = nil
local state = {["creator-prs"] = {}, ["reviewer-prs"] = {}, ["ci-status"] = {}, ["last-update"] = nil}
local function make_icon()
  local ascii = "ASCII:\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . . . . . . . . . . . . . .\n. . 1 . . . 1 . . . 8 . . . 8 . .\n. . . . . . . . . . . . . . . . .\n. . . . 1 . . . . . . . 8 . . . .\n. . . . 2 . . . . . . . 7 . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 4 . . 5 . . . 6 . . . . .\n. . . . 2 . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . 3 . . . 3 . . . . . . . . . .\n. . . . . . . . . . . . . . . . .\n. . . . 3 . . . . . . . . . . . .\n. . . . . . . . . . . . . . . . ."
  local context = {{strokeColor = {red = 1, green = 1, blue = 1, alpha = 1}, fillColor = {alpha = 0}, lineWidth = 1.2, shouldClose = false}}
  return hs.image.imageFromASCII(ascii, context)
end
local function get_pull_request_url(pr)
  local _2_
  do
    local t_1_ = pr
    if (nil ~= t_1_) then
      t_1_ = t_1_.repository
    else
    end
    _2_ = t_1_
  end
  local _5_
  do
    local t_4_ = pr
    if (nil ~= t_4_) then
      t_4_ = t_4_.id
    else
    end
    _5_ = t_4_
  end
  return (obj.organizationUrl .. obj.project .. "/_git/" .. _2_ .. "/pullrequest/" .. _5_)
end
local function get_status_emoji(pull_request)
  local case_7_
  do
    local t_8_ = pull_request
    if (nil ~= t_8_) then
      t_8_ = t_8_.mergeStatus
    else
    end
    case_7_ = t_8_
  end
  if (case_7_ == "succeeded") then
    return "\226\156\133 "
  elseif (case_7_ == "rejectedByPolicy") then
    return "\226\157\140 "
  elseif (case_7_ == "conflicts") then
    return "\226\154\148\239\184\143 "
  else
    local _ = case_7_
    return "\226\143\179 "
  end
end
local function get_menu_title(total_count)
  return hs.styledtext.new(tostring(total_count))
end
local function get_error_title()
  local error_style = {color = {red = 1.0, green = 0, blue = 0, alpha = 1.0}}
  return hs.styledtext.new("error", error_style)
end
local function show_error(error_message)
  obj.logger.e(error_message)
  obj.menuItem:setTitle(get_error_title())
  return obj.menuItem:setMenu(nil)
end
local function get_ci_status_style(pull_request)
  local pr_id
  do
    local t_11_ = pull_request
    if (nil ~= t_11_) then
      t_11_ = t_11_.id
    else
    end
    pr_id = t_11_
  end
  local ci_status = state["ci-status"][pr_id]
  if (ci_status == "passed") then
    return {color = {red = 0, green = 0.6, blue = 0, alpha = 1.0}}
  elseif (ci_status == "failed") then
    return {color = {red = 0.8, green = 0, blue = 0, alpha = 1.0}}
  else
    local _ = ci_status
    return {}
  end
end
local function has_merge_conflicts(pull_request)
  local _15_
  do
    local t_14_ = pull_request
    if (nil ~= t_14_) then
      t_14_ = t_14_.mergeStatus
    else
    end
    _15_ = t_14_
  end
  return (_15_ == "conflicts")
end
local function get_title(pull_request)
  local title
  do
    local t_17_ = pull_request
    if (nil ~= t_17_) then
      t_17_ = t_17_.title
    else
    end
    title = t_17_
  end
  local emoji = get_status_emoji(pull_request)
  local draft_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local conflict_style = {color = {red = 0.9, green = 0.7, blue = 0, alpha = 1.0}}
  local ci_style = get_ci_status_style(pull_request)
  local text
  local _20_
  do
    local t_19_ = pull_request
    if (nil ~= t_19_) then
      t_19_ = t_19_.isDraft
    else
    end
    _20_ = t_19_
  end
  if _20_ then
    text = ("[Draft] " .. title)
  else
    text = title
  end
  local style
  local _24_
  do
    local t_23_ = pull_request
    if (nil ~= t_23_) then
      t_23_ = t_23_.isDraft
    else
    end
    _24_ = t_23_
  end
  if _24_ then
    style = draft_style
  elseif has_merge_conflicts(pull_request) then
    style = conflict_style
  else
    style = ci_style
  end
  return hs.styledtext.new((emoji .. text), style)
end
local function get_menu_line(pull_request)
  local function _27_()
    return hs.urlevent.openURL(get_pull_request_url(pull_request))
  end
  return {title = get_title(pull_request), fn = _27_}
end
local function get_last_update_text()
  if state["last-update"] then
    return ("Last update: " .. os.date("%Y-%m-%d %H:%M:%S", state["last-update"]))
  else
    return "Last update: never"
  end
end
local function get_menu_table(creator_prs, reviewer_prs)
  local menu_table = {}
  local separator = {title = "-"}
  local empty_style = {color = {red = 0.5, green = 0.5, blue = 0.5, alpha = 1.0}}
  local empty_block = {title = hs.styledtext.new("n/a", empty_style)}
  local reload_line
  local function _29_()
    return hs.reload()
  end
  reload_line = {title = "\240\159\148\132 Reload Hammerspoon", fn = _29_}
  local last_update_line = {title = hs.styledtext.new(get_last_update_text(), empty_style), disabled = true}
  if (#creator_prs > 0) then
    for _, pr in ipairs(creator_prs) do
      table.insert(menu_table, get_menu_line(pr))
    end
  else
    table.insert(menu_table, empty_block)
  end
  table.insert(menu_table, separator)
  if (#reviewer_prs > 0) then
    for _, pr in ipairs(reviewer_prs) do
      table.insert(menu_table, get_menu_line(pr))
    end
  else
    table.insert(menu_table, empty_block)
  end
  table.insert(menu_table, separator)
  table.insert(menu_table, reload_line)
  table.insert(menu_table, last_update_line)
  return menu_table
end
local function parse_pr_response(json_output)
  local prs = (hs.json.decode(json_output) or {})
  return prs
end
local function parse_ci_status(policies)
  local build_policies
  do
    local tbl_26_ = {}
    local i_27_ = 0
    for _, p in ipairs(policies) do
      local val_28_
      local _33_
      do
        local t_32_ = p
        if (nil ~= t_32_) then
          t_32_ = t_32_.configuration
        else
        end
        if (nil ~= t_32_) then
          t_32_ = t_32_.type
        else
        end
        if (nil ~= t_32_) then
          t_32_ = t_32_.displayName
        else
        end
        _33_ = t_32_
      end
      if (_33_ == "Build") then
        val_28_ = p
      else
        val_28_ = nil
      end
      if (nil ~= val_28_) then
        i_27_ = (i_27_ + 1)
        tbl_26_[i_27_] = val_28_
      else
      end
    end
    build_policies = tbl_26_
  end
  if (#build_policies == 0) then
    return nil
  else
    local has_rejected = false
    local all_approved = true
    for _, p in ipairs(build_policies) do
      local status
      do
        local t_39_ = p
        if (nil ~= t_39_) then
          t_39_ = t_39_.status
        else
        end
        status = t_39_
      end
      if (status == "rejected") then
        has_rejected = true
      else
      end
      if (status ~= "approved") then
        all_approved = false
      else
      end
    end
    if has_rejected then
      return "failed"
    elseif all_approved then
      return "passed"
    else
      return nil
    end
  end
end
local update_menu = nil
local function make_policy_callback(pr_id)
  local function _45_(exit_code, std_out, _std_err)
    if (exit_code == 0) then
      local policies = (hs.json.decode(std_out) or {})
      local ci_status = parse_ci_status(policies)
      state["ci-status"][pr_id] = ci_status
      return update_menu()
    else
      return nil
    end
  end
  return _45_
end
local function fetch_policy_status(pr_id)
  local args = {"repos", "pr", "policy", "list", "--id", tostring(pr_id), "--organization", obj.organizationUrl}
  local callback = make_policy_callback(pr_id)
  local task = hs.task.new(obj.azPath, callback, args)
  return task:start()
end
local function fetch_policy_status_for_prs(prs)
  for _, pr in ipairs(prs) do
    local pr_id
    do
      local t_47_ = pr
      if (nil ~= t_47_) then
        t_47_ = t_47_.id
      else
      end
      pr_id = t_47_
    end
    if pr_id then
      fetch_policy_status(pr_id)
    else
    end
  end
  return nil
end
local function _50_()
  local creator_prs = state["creator-prs"]
  local reviewer_prs = state["reviewer-prs"]
  local total_count = (#creator_prs + #reviewer_prs)
  local menu_title = get_menu_title(total_count)
  local menu_table = get_menu_table(creator_prs, reviewer_prs)
  obj.menuItem:setTitle(menu_title)
  return obj.menuItem:setMenu(menu_table)
end
update_menu = _50_
local function creator_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local prs = parse_pr_response(std_out)
    state["creator-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch creator PRs: " .. std_err))
  end
end
local function reviewer_callback(exit_code, std_out, std_err)
  if (exit_code == 0) then
    local prs = parse_pr_response(std_out)
    state["reviewer-prs"] = prs
    update_menu()
    return fetch_policy_status_for_prs(prs)
  else
    return show_error(("Failed to fetch reviewer PRs: " .. std_err))
  end
end
local function fetch_creator_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--creator", obj.userEmail}
  local task = hs.task.new(obj.azPath, creator_callback, args)
  return task:start()
end
local function fetch_reviewer_prs()
  local query = ("[].{" .. "authorEmail: createdBy.uniqueName," .. "authorName: createdBy.displayName," .. "isDraft: isDraft," .. "title: title," .. "id: pullRequestId," .. "repository: repository.name," .. "mergeStatus: mergeStatus" .. "}")
  local args = {"repos", "pr", "list", "--organization", obj.organizationUrl, "--project", obj.project, "--query", query, "--reviewer", obj.userEmail}
  local task = hs.task.new(obj.azPath, reviewer_callback, args)
  return task:start()
end
local function update()
  state["last-update"] = os.time()
  fetch_creator_prs()
  return fetch_reviewer_prs()
end
obj.init = function(self)
  self.logger = hs.logger.new("PullRequestAzure")
  self.menuItem = hs.menubar.new()
  do
    local icon = make_icon()
    self.menuItem:setIcon(icon, true)
  end
  self.timer = hs.timer.new(60, update)
  return self
end
obj.start = function(self)
  self.menuItem:setTitle("...")
  self.timer:start()
  self.timer:setNextTrigger(0)
  return self
end
obj.stop = function(self)
  self.timer:stop()
  self.menuItem:setTitle("...")
  self.menuItem:setMenu(nil)
  state["creator-prs"] = {}
  state["reviewer-prs"] = {}
  state["ci-status"] = {}
  state["last-update"] = nil
  return self
end
return obj
